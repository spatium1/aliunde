# -*- coding: utf-8 -*-
import urllib
import urllib2
import datetime
import re
import os
import base64
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
from BeautifulSoup import BeautifulStoneSoup , BeautifulSoup , BeautifulSOAP
try :
 import json
except :
 import simplejson as json
import SimpleDownloader as downloader
import time
import requests
import _Edit
if 64 - 64: i11iIiiIii
OO0o = ''
Oo0Ooo = ''
O0O0OO0O0O0 = ''
iiiii = ''
ooo0OO = ''
II1 = ''
O00ooooo00 = ''
I1IiiI = ''
IIi1IiiiI1Ii = ''
I11i11Ii = ''
oO00oOo = ''
OOOo0 = ''
Oooo000o = ''
IiIi11iIIi1Ii = ''
Oo0O = ''
if 44 - 44: iiiiIi11i . o0O / OoOO + I1iII1iiII
iI1Ii11111iIi = [ 'alldebrid.com' , 'allmyvideos.net' , 'allvid.ch' , 'auengine.com' , 'beststreams.net' , 'briskfile.com' , 'castamp.com' , 'clicknupload.com' , 'clicknupload.me' , 'clicknupload.link' , 'cloudy.ec' , 'cloudzilla.to' , 'neodrive.co' , 'crunchyroll.com' , 'daclips.in' , 'daclips.com' , 'dailymotion.com' , 'divxstage.eu' , 'divxstage.net' , 'divxstage.to' , 'couldtime.to' , 'ecostream.tv' , 'exashare.com' , 'facebook.com' , 'fastplay.sx' , 'filehoot.com' , 'filenuke.com' , 'filepup.net' , 'filmshowonline.net' , 'flashx.tv' , 'plus.google.com' , 'googlevideo.com' , 'picasaweb.google.com' , 'googleusercontent.com' , 'googledrive.com' , 'gorillavid.in' , 'gorillavid.com' , 'gorillavid.in' , 'grifthost.com' , 'hugefiles.net' , 'idowatch.net' , 'indavideo.hu' , 'ishared.eu' , 'jetload.tv' , 'kingfiles.net' , 'letwatch.us' , 'letwatch.to' , 'vidshare.us' , 'mail.ru' , 'my.mail.ru' , 'videoapi.my.mail.ru' , 'api.video.mail.ru' , 'mega-debrid.eu' , 'megamp4.net' , 'mersalaayitten.com' , 'movdivx.com' , 'movpod.net' , 'movpod.in' , 'movshare.net' , 'wholecloud.net' , 'mp4engine.com' , 'mp4stream.com' , 'mp4upload.com' , 'myvidstream.net' , 'nosvideo.com' , 'noslocker.com' , 'auroravid.to' , 'novamov.com' , 'nowvideo.sx' , 'nowvideo.eu' , 'nowvideo.ch' , 'nowvideo.sx' , 'nowvideo.co' , 'nowvideo.li' , 'nowvideo.ec' , 'nowvideo.at' , 'nowvideo.fo' , 'ok.ru' , 'odnoklassniki.ru' , 'openload.io' , 'openload.co' , 'play44.net' , 'played.to' , 'playhd.video' , 'playhd.fo' , 'playu.net' , 'playu.me' , 'playwire.com' , 'Premiumize.me' , 'primeshare.tv' , 'promptfile.com' , 'purevid.com' , 'rapidvideo.ws' , 'rapidvideo.com' , 'api.real-debrid.com' , 'premium.rpnet.biz' , 'rutube.ru' , 'shared2.me' , 'shared.sx' , 'sharerepo.com' , 'sharesix.com' , 'simply-debrid.com' , 'speedplay.xyz' , 'speedplay.us' , 'speedplay3.pw' , 'speedvideo.net' , 'stagevu.com' , 'streamcloud.eu' , 'streamin.to' , 'teramixer.com' , 'thevideo.me' , 'thevideos.tv' , 'toltsd-fel.tk' , 'trollvid.net' , 'tune.pk' , 'tusfiles.net' , 'twitch.tv' , 'up2stream.com' , 'upload.af' , 'uploadc.com' , 'uploadc.ch' , 'zalaa.com' , 'uploadx.org' , 'uptobox.com' , 'uptostream.com' , 'userfiles.com' , 'userscloud.com' , 'veehd.com' , 'veoh.com' , 'vid.ag' , 'vidbull.com' , 'vidcrazy.net' , 'uploadcrazy.net' , 'thevideobee.to' , 'videoboxer.co' , 'vidgg.to' , 'vid.gg' , 'videohut.to' , 'videomega.tv' , 'videoraj.to' , 'videorev.cc' , 'videosky.to' , 'video.tt' , 'videoweed.es' , 'bitvid.sx' , 'videoweed.com' , 'videowood.tv' , 'byzoo.org' , 'playpanda.net' , 'videozoo.me' , 'videowing.me' , 'videowing.me' , 'easyvideo.me' , 'play44.net' , 'playbb.me' , 'video44.net' , 'vidio.sx' , 'vid.me' , 'vidspot.net' , 'vidto.me' , 'vidup.me' , 'vidup.org' , 'vidzi.tv' , 'vimeo.com' , 'vivo.sx' , 'vk.com' , 'vkpass.com' , 'vodlocker.com' , 'vshare.io' , 'vshare.eu' , 'watchers.to' , 'watchonline.to' , 'watchvideo.us' , 'watchvideo2.us' , 'watchvideo3.us' , 'watchvideo4.us' , 'watchvideo5.us' , 'watchvideo6.us' , 'watchvideo7.us' , 'watchvideo8.us' , 'watchvideo9.us' , 'weshare.me' , 'xvidstage.com' , 'youlol.biz' , 'shitmovie.com' , 'yourupload.com' , 'youtube.com' , 'youtu.be' , 'youwatch.org' , 'api.zevera.com' , 'zettahost.tv' , 'zstream.to' ]
i1i1II = [ 'plugin.video.dramasonline' , 'plugin.video.f4mTester' , 'plugin.video.shahidmbcnet' , 'plugin.video.SportsDevil' , 'plugin.stream.vaughnlive.tv' , 'plugin.video.ZemTV-shani' ]
if 96 - 96: o0OO0 - Oo0ooO0oo0oO . I1i1iI1i - o00ooo0 / o00 * Oo0oO0ooo
class o0oOoO00o ( urllib2 . HTTPErrorProcessor ) :
 def http_response ( self , request , response ) :
  return response
 https_response = http_response
 if 43 - 43: O0OOo . II1Iiii1111i
i1IIi11111i = _Edit . addon
o000o0o00o0Oo = i1IIi11111i . getAddonInfo ( 'version' )
oo = xbmc . translatePath ( i1IIi11111i . getAddonInfo ( 'profile' ) . decode ( 'utf-8' ) )
IiII1I1i1i1ii = xbmc . translatePath ( i1IIi11111i . getAddonInfo ( 'path' ) . decode ( 'utf-8' ) )
IIIII = os . path . join ( oo , 'favorites' )
I1 = os . path . join ( oo , 'history' )
if 54 - 54: oO % IiiIIiiI11 / oooOOOOO * IiiIII111ii / i1iIIi1
ii11iIi1I = os . path . join ( oo , 'list_revision' )
iI111I11I1I1 = os . path . join ( IiII1I1i1i1ii , 'icon.png' )
OOooO0OOoo = os . path . join ( IiII1I1i1i1ii , 'fanart.jpg' )
iIii1 = os . path . join ( oo , 'source_file' )
oOOoO0 = oo
if 59 - 59: oOOO0OOooOoO0Oo * II + i11iIiiIii - o0O - o00
downloader = downloader . SimpleDownloader ( )
ii1I = i1IIi11111i . getSetting ( 'debug' )
if os . path . exists ( IIIII ) == True :
 OooO0 = open ( IIIII ) . read ( )
else : OooO0 = [ ]
if os . path . exists ( iIii1 ) == True :
 II11iiii1Ii = open ( iIii1 ) . read ( )
else : II11iiii1Ii = [ ]
if 70 - 70: II1Iiii1111i / o0O % II % i11iIiiIii . Oo0ooO0oo0oO
if 68 - 68: IiiIIiiI11 + oO . o0O - i1iIIi1 % o0O - II
def oOOO00o ( string ) :
 if ii1I == 'true' :
  xbmc . log ( "[addon.live.Furious Streams Lists-%s]: %s" % ( o000o0o00o0Oo , string ) )
  if 97 - 97: IiiIIiiI11 % IiiIIiiI11 + o0OO0 * IiiIII111ii
  if 54 - 54: IiiIIiiI11 + i1iIIi1 / IiiIII111ii
def IIII ( url , headers = None ) :
 try :
  if headers is None :
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
  Ii1I = urllib2 . Request ( url , None , headers )
  Oo0o0 = urllib2 . urlopen ( Ii1I )
  III1ii1iII = Oo0o0 . read ( )
  Oo0o0 . close ( )
  return III1ii1iII
 except urllib2 . URLError , oo0oooooO0 :
  oOOO00o ( 'URL: ' + url )
  if hasattr ( oo0oooooO0 , 'code' ) :
   oOOO00o ( 'We failed with error code - %s.' % oo0oooooO0 . code )
   xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,We failed with error code - " + str ( oo0oooooO0 . code ) + ",10000," + iI111I11I1I1 + ")" )
  elif hasattr ( oo0oooooO0 , 'reason' ) :
   oOOO00o ( 'We failed to reach a server.' )
   oOOO00o ( 'Reason: %s' % oo0oooooO0 . reason )
   xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,We failed to reach a server. - " + str ( oo0oooooO0 . reason ) + ",10000," + iI111I11I1I1 + ")" )
   if 19 - 19: IiiIIiiI11 + II
   if 53 - 53: OoOO . I1iII1iiII
def ii1I1i1I ( ) :
 oOOO00o ( "SKindex" )
 OOoo0O0 ( _Edit . MainBase , '' )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 41 - 41: II1Iiii1111i
def ii1i1I1i ( url ) :
 Ii1I = urllib2 . Request ( url )
 Ii1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 Oo0o0 = ''
 o00oOO0 = ''
 try :
  Oo0o0 = urllib2 . urlopen ( Ii1I )
  o00oOO0 = Oo0o0 . read ( )
  Oo0o0 . close ( )
 except : pass
 if o00oOO0 != '' :
  return o00oOO0
 else :
  o00oOO0 = 'Opened'
  return o00oOO0
  if 95 - 95: oO / OoOO
def iI ( url ) :
 o00O = xbmcgui . Dialog ( )
 OOO0OOO00oo = o00O . input ( 'Search' , type = xbmcgui . INPUT_ALPHANUM )
 Iii111II = OOO0OOO00oo . lower ( )
 if Iii111II == '' :
  pass
 else :
  iiii11I ( Iii111II , url )
  if 96 - 96: o0OO0 % oooOOOOO . oO + OoOO * II1Iiii1111i - o00
def iiii11I ( Search_name , url ) :
 i11i1 = ii1i1I1i ( url )
 if i11i1 != 'Failed' :
  IIIii1II1II = re . compile ( '<channel>.+?<name>(.+?)</name>.+?<thumbnail>(.+?)</thumbnail>.+?<externallink>(.+?)</externallink>.+?<fanart>(.+?)</fanart>.+?</channel>' , re . DOTALL ) . findall ( i11i1 )
  for i1I1iI , oo0OooOOo0 , url , o0OO00oO in IIIii1II1II :
   if not 'http:' in url :
    pass
   else :
    iiii11I ( Search_name , url )
  I11i1I1I = re . compile ( '<title>(.+?)</title>.+?<link>(.+?)</link>.+?<thumbnail>(.+?)</thumbnail>.+?<fanart>(.+?)</fanart>' , re . DOTALL ) . findall ( i11i1 )
  for i1I1iI , url , oo0OooOOo0 , o0OO00oO in I11i1I1I :
   if 'http:' in url :
    if Search_name . lower ( ) in i1I1iI . lower ( ) :
     oO0Oo ( url , i1I1iI , oo0OooOOo0 , o0OO00oO , '' , '' , '' , '' , None , '' , 1 )
     if 54 - 54: Oo0oO0ooo - Oo0ooO0oo0oO + OoOO
     if 70 - 70: oooOOOOO / IiiIIiiI11 . IiiIII111ii % I1i1iI1i
     if 67 - 67: o00 * Oo0oO0ooo . i1iIIi1 - o00ooo0 * Oo0oO0ooo
import base64
import xbmcgui
import requests
if 46 - 46: oO + o00 . Oo0ooO0oo0oO * II1Iiii1111i % i1iIIi1
def Oo000o ( st ) :
 import re
 st = re . sub ( '\[.+\]' , '' , st )
 import string
 I11IiI1I11i1i = 0
 for iI1ii1Ii in st :
  if iI1ii1Ii in 'lij|\' ' : I11IiI1I11i1i += 37
  elif iI1ii1Ii in '![]fI.,:;/\\t' : I11IiI1I11i1i += 50
  elif iI1ii1Ii in '`-(){}r"' : I11IiI1I11i1i += 60
  elif iI1ii1Ii in '*^zcsJkvxy' : I11IiI1I11i1i += 85
  elif iI1ii1Ii in 'aebdhnopqug#$L+<>=?_~FZT' + string . digits : I11IiI1I11i1i += 95
  elif iI1ii1Ii in 'BSPEAKVXY&UwNRCHD' : I11IiI1I11i1i += 112
  elif iI1ii1Ii in 'QGOMm%W@' : I11IiI1I11i1i += 135
  else : I11IiI1I11i1i += 50
 return int ( I11IiI1I11i1i * 6.5 / 100 )
 if 92 - 92: o00
def i1 ( Heading = xbmcaddon . Addon ( ) . getAddonInfo ( 'name' ) ) :
 OOO = xbmc . Keyboard ( '' , Heading )
 OOO . doModal ( )
 if ( OOO . isConfirmed ( ) ) :
  return OOO . getText ( )
  if 59 - 59: o0OO0 + OoOO * o00 + I1iII1iiII
def Oo0OoO00oOO0o ( url ) :
 if 80 - 80: II1Iiii1111i + oO - oO % IiiIII111ii
 import webbrowser
 if 63 - 63: Oo0ooO0oo0oO - O0OOo + iiiiIi11i % IiiIIiiI11 / o0O / Oo0oO0ooo
 O0o0O00Oo0o0 = webbrowser . open
 O00O0oOO00O00 = xbmc . executebuiltin
 i1Oo00 = lambda i1i : xbmc . getCondVisibility ( str ( i1i ) )
 iiI111I1iIiI = lambda i1i : O00O0oOO00O00 ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( i1i ) )
 if 41 - 41: I1i1iI1i . II + iiiiIi11i * Oo0oO0ooo % I1i1iI1i * I1i1iI1i
 iIIIIi1iiIi1 = 'System.Platform.Android'
 if 21 - 21: Oo0ooO0oo0oO * o0O
 if i1Oo00 ( iIIIIi1iiIi1 ) : iiI111I1iIiI ( base64 . b64decode ( url ) )
 else : O0o0O00Oo0o0 ( base64 . b64decode ( url ) )
 if 91 - 91: i1iIIi1
 if 15 - 15: o0OO0
def Ii ( ) :
 if 79 - 79: OoOO / iiiiIi11i
 if 75 - 75: o00 % Oo0oO0ooo % Oo0oO0ooo . oOOO0OOooOoO0Oo
 import sys
 if 5 - 5: Oo0oO0ooo * II + o00 . oO + o00
 oOiIi1IIIi1 = 'aHR0cDovL2JyZXR0dXNidWlsZHMuY29tL2Z1cmlvdXM='
 O0oOoOOOoOO = 'MjMzNTU1NmViYjQ3NTcy'
 ii1ii11IIIiiI = base64 . b64decode ( 'aHR0cDovL29mZnNob3JlcGx1Z2lucy5jb20vcG9ydGFsL2FwaS5waHA/cGluPSVzJmtleT0=' ) + base64 . b64decode ( O0oOoOOOoOO )
 O00OOOoOoo0O = 'W0NPTE9SIGJsdWVdSW4gb3JkZXIgdG8gY29udGludWUgcGxlYXNlWy9DT0xPUl0gW0NPTE9SIHdoaXRlXVtCXVZFUklGWVsvQl1bL0NPTE9SXSBbQ09MT1IgYmx1ZV15b3VyIGRldmljZSBieSBnZXR0aW5nIGEgcGluIGZyb20gb3VyIHdlYnNpdGUgYW5kIGVudGVyaW5nIHRoZSBwaW4gb24gdGhlIG5leHQgcHJvbXQuWy9DT0xPUl1bQ09MT1Igd2hpdGVdW0JdIHd3dy5icmV0dHVzYnVpbGRzLmNvbS9mdXJpb3VzIFsvQl1bL0NPTE9SXQ=='
 if 77 - 77: IiiIII111ii % IiiIII111ii * II1Iiii1111i - i11iIiiIii
 Oo0oO = base64 . b64decode ( O00OOOoOoo0O )
 IIiIi1iI = xbmcaddon . Addon ( ) . getAddonInfo
 i1IiiiI1iI = xbmcaddon . Addon ( ) . getSetting ( 'pin' )
 i1iIi = lambda i1i : base64 . b64decode ( str ( i1i ) )
 ooOOoooooo = lambda i1i : requests . get ( ii1ii11IIIiiI % ( i1i ) ) . text . strip ( )
 II1I = lambda i1i : xbmcaddon . Addon ( ) . setSetting ( base64 . b64decode ( 'cGlu' ) , i1i )
 O0 = lambda i1i : xbmcgui . Dialog ( ) . yesno ( IIiIi1iI ( 'name' ) , i1i , yeslabel = "Get A Pin" , nolabel = 'Cancel' )
 i1II1Iiii1I11 = bool ( ooOOoooooo ( i1IiiiI1iI ) == base64 . b64decode ( 'UGluIFZlcmlmaWVk' ) )
 if 9 - 9: O0OOo / I1i1iI1i - Oo0ooO0oo0oO / OoOO / o0O - Oo0oO0ooo
 if i1II1Iiii1I11 : return
 else :
  if 91 - 91: IiiIII111ii % I1iII1iiII % o0O
  if O0 ( Oo0oO ) :
   Oo0OoO00oOO0o ( oOiIi1IIIi1 )
   IIi1I11I1II = i1 ( 'Type Your Pin Here' )
   II1I ( IIi1I11I1II )
   Ii ( )
  else : sys . exit ( )
  if 63 - 63: OoOO - o00ooo0 . o0OO0 / Oo0oO0ooo . o00 / iiiiIi11i
  if 84 - 84: i1iIIi1
  if 86 - 86: o00 - oooOOOOO - o00ooo0 * IiiIII111ii
  if 66 - 66: OoOO + iiiiIi11i
def I1IiiIIIi ( ) :
 if os . path . exists ( IIIII ) == True :
  i1Iii1i1I ( 'Favorites' , 'url' , 4 , os . path . join ( IiII1I1i1i1ii , 'resources' , 'favorite.png' ) , OOooO0OOoo , '' , '' , '' , '' )
 if i1IIi11111i . getSetting ( "browse_xml_database" ) == "true" :
  i1Iii1i1I ( 'XML Database' , 'http://xbmcplus.xb.funpic.de/www-data/filesystem/' , 15 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if i1IIi11111i . getSetting ( "browse_community" ) == "true" :
  i1Iii1i1I ( 'Community Files' , 'community_files' , 16 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if os . path . exists ( I1 ) == True :
  i1Iii1i1I ( 'Search History' , 'history' , 25 , os . path . join ( IiII1I1i1i1ii , 'resources' , 'favorite.png' ) , OOooO0OOoo , '' , '' , '' , '' )
 if i1IIi11111i . getSetting ( "searchyt" ) == "true" :
  i1Iii1i1I ( 'Search:Youtube' , 'youtube' , 25 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if i1IIi11111i . getSetting ( "searchDM" ) == "true" :
  i1Iii1i1I ( 'Search:dailymotion' , 'dmotion' , 25 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if i1IIi11111i . getSetting ( "PulsarM" ) == "true" :
  i1Iii1i1I ( 'Pulsar:IMDB' , 'IMDBidplay' , 27 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if os . path . exists ( iIii1 ) == True :
  OOoO00 = json . loads ( open ( iIii1 , "r" ) . read ( ) )
  if 40 - 40: Oo0ooO0oo0oO * oooOOOOO + oO % IiiIII111ii
  if len ( OOoO00 ) > 1 :
   for OOOOOoo0 in OOoO00 :
    if 49 - 49: iiiiIi11i . IiiIII111ii
    if isinstance ( OOOOOoo0 , list ) :
     i1Iii1i1I ( OOOOOoo0 [ 0 ] . encode ( 'utf-8' ) , OOOOOoo0 [ 1 ] . encode ( 'utf-8' ) , 1 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' , 'source' )
    else :
     I1iI1iIi111i = iI111I11I1I1
     o0OO00oO = OOooO0OOoo
     iiIi1IIi1I = ''
     o0OoOO000ooO0 = ''
     credits = ''
     o0o0o0oO0oOO = ''
     if OOOOOoo0 . has_key ( 'thumbnail' ) :
      I1iI1iIi111i = OOOOOoo0 [ 'thumbnail' ]
     if OOOOOoo0 . has_key ( 'fanart' ) :
      o0OO00oO = OOOOOoo0 [ 'fanart' ]
     if OOOOOoo0 . has_key ( 'description' ) :
      iiIi1IIi1I = OOOOOoo0 [ 'description' ]
     if OOOOOoo0 . has_key ( 'date' ) :
      o0OoOO000ooO0 = OOOOOoo0 [ 'date' ]
     if OOOOOoo0 . has_key ( 'genre' ) :
      o0o0o0oO0oOO = OOOOOoo0 [ 'genre' ]
     if OOOOOoo0 . has_key ( 'credits' ) :
      credits = OOOOOoo0 [ 'credits' ]
     i1Iii1i1I ( OOOOOoo0 [ 'title' ] . encode ( 'utf-8' ) , OOOOOoo0 [ 'url' ] . encode ( 'utf-8' ) , 1 , I1iI1iIi111i , o0OO00oO , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , credits , 'source' )
     if 3 - 3: Oo0oO0ooo
  else :
   if len ( OOoO00 ) == 1 :
    if isinstance ( OOoO00 [ 0 ] , list ) :
     OOoo0O0 ( OOoO00 [ 0 ] [ 1 ] . encode ( 'utf-8' ) , OOooO0OOoo )
    else :
     OOoo0O0 ( OOoO00 [ 0 ] [ 'url' ] , OOoO00 [ 0 ] [ 'fanart' ] )
     if 24 - 24: i11iIiiIii + IiiIII111ii * oooOOOOO - o0OO0 . oO % o0O
     if 71 - 71: iiiiIi11i . IiiIII111ii / Oo0oO0ooo
def Ooo ( url = None ) :
 if url is None :
  if not i1IIi11111i . getSetting ( "new_file_source" ) == "" :
   iIi1IiIiiII = i1IIi11111i . getSetting ( 'new_file_source' ) . decode ( 'utf-8' )
  elif not i1IIi11111i . getSetting ( "new_url_source" ) == "" :
   iIi1IiIiiII = i1IIi11111i . getSetting ( 'new_url_source' ) . decode ( 'utf-8' )
 else :
  iIi1IiIiiII = url
 if iIi1IiIiiII == '' or iIi1IiIiiII is None :
  return
 oOOO00o ( 'Adding New Source: ' + iIi1IiIiiII . encode ( 'utf-8' ) )
 if 25 - 25: iiiiIi11i - iiiiIi11i * Oo0oO0ooo
 OOOO0oo0 = None
 if 35 - 35: oooOOOOO - Oo0ooO0oo0oO % Oo0oO0ooo . OoOO % oooOOOOO
 III1ii1iII = I1i1Iiiii ( iIi1IiIiiII )
 print 'source_url' , iIi1IiIiiII
 if isinstance ( III1ii1iII , BeautifulSOAP ) :
  if III1ii1iII . find ( 'channels_info' ) :
   OOOO0oo0 = III1ii1iII . channels_info
  elif III1ii1iII . find ( 'items_info' ) :
   OOOO0oo0 = III1ii1iII . items_info
 if OOOO0oo0 :
  OOo0oO00ooO00 = { }
  OOo0oO00ooO00 [ 'url' ] = iIi1IiIiiII
  try : OOo0oO00ooO00 [ 'title' ] = OOOO0oo0 . title . string
  except : pass
  try : OOo0oO00ooO00 [ 'thumbnail' ] = OOOO0oo0 . thumbnail . string
  except : pass
  try : OOo0oO00ooO00 [ 'fanart' ] = OOOO0oo0 . fanart . string
  except : pass
  try : OOo0oO00ooO00 [ 'genre' ] = OOOO0oo0 . genre . string
  except : pass
  try : OOo0oO00ooO00 [ 'description' ] = OOOO0oo0 . description . string
  except : pass
  try : OOo0oO00ooO00 [ 'date' ] = OOOO0oo0 . date . string
  except : pass
  try : OOo0oO00ooO00 [ 'credits' ] = OOOO0oo0 . credits . string
  except : pass
 else :
  if '/' in iIi1IiIiiII :
   oOO0O00oO0Ooo = iIi1IiIiiII . split ( '/' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '\\' in iIi1IiIiiII :
   oOO0O00oO0Ooo = iIi1IiIiiII . split ( '\\' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '%' in oOO0O00oO0Ooo :
   oOO0O00oO0Ooo = urllib . unquote_plus ( oOO0O00oO0Ooo )
  oO0Oo0O0o = xbmc . Keyboard ( oOO0O00oO0Ooo , 'Displayed Name, Rename?' )
  oO0Oo0O0o . doModal ( )
  if ( oO0Oo0O0o . isConfirmed ( ) == False ) :
   return
  OO = oO0Oo0O0o . getText ( )
  if len ( OO ) == 0 :
   return
  OOo0oO00ooO00 = { }
  OOo0oO00ooO00 [ 'title' ] = OO
  OOo0oO00ooO00 [ 'url' ] = iIi1IiIiiII
  OOo0oO00ooO00 [ 'fanart' ] = o0OO00oO
  if 37 - 37: II % II1Iiii1111i . i11iIiiIii % oooOOOOO . I1i1iI1i
 if os . path . exists ( iIii1 ) == False :
  I11I1IIII = [ ]
  I11I1IIII . append ( OOo0oO00ooO00 )
  iIIIiiI1i1 = open ( iIii1 , "w" )
  iIIIiiI1i1 . write ( json . dumps ( I11I1IIII ) )
  iIIIiiI1i1 . close ( )
 else :
  OOoO00 = json . loads ( open ( iIii1 , "r" ) . read ( ) )
  OOoO00 . append ( OOo0oO00ooO00 )
  iIIIiiI1i1 = open ( iIii1 , "w" )
  iIIIiiI1i1 . write ( json . dumps ( OOoO00 ) )
  iIIIiiI1i1 . close ( )
 i1IIi11111i . setSetting ( 'new_url_source' , "" )
 i1IIi11111i . setSetting ( 'new_file_source' , "" )
 xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,New source added.,5000," + iI111I11I1I1 + ")" )
 if not url is None :
  if 'xbmcplus.xb.funpic.de' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=14,replace)" % sys . argv [ 0 ] )
  elif 'community-links' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=10,replace)" % sys . argv [ 0 ] )
 else : i1IIi11111i . openSettings ( )
 if 50 - 50: i1iIIi1
 if 46 - 46: iiiiIi11i + IiiIII111ii % Oo0ooO0oo0oO / Oo0oO0ooo . i1iIIi1 * IiiIIiiI11
def OOooo0oOO0O ( name ) :
 OOoO00 = json . loads ( open ( iIii1 , "r" ) . read ( ) )
 for o00O0 in range ( len ( OOoO00 ) ) :
  if isinstance ( OOoO00 [ o00O0 ] , list ) :
   if OOoO00 [ o00O0 ] [ 0 ] == name :
    del OOoO00 [ o00O0 ]
    iIIIiiI1i1 = open ( iIii1 , "w" )
    iIIIiiI1i1 . write ( json . dumps ( OOoO00 ) )
    iIIIiiI1i1 . close ( )
    break
  else :
   if OOoO00 [ o00O0 ] [ 'title' ] == name :
    del OOoO00 [ o00O0 ]
    iIIIiiI1i1 = open ( iIii1 , "w" )
    iIIIiiI1i1 . write ( json . dumps ( OOoO00 ) )
    iIIIiiI1i1 . close ( )
    break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 83 - 83: II
 if 65 - 65: Oo0ooO0oo0oO % oooOOOOO * II1Iiii1111i
 if 19 - 19: oOOO0OOooOoO0Oo + o0O . OoOO . IiiIIiiI11 / oOOO0OOooOoO0Oo + i1iIIi1
def oOooOOo0o ( url , browse = False ) :
 if url is None :
  url = 'http://xbmcplus.xb.funpic.de/www-data/filesystem/'
 O0O0ooOOO = BeautifulSoup ( IIII ( url ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 for OOOOOoo0 in O0O0ooOOO ( 'a' ) :
  oOOo0O00o = OOOOOoo0 [ 'href' ]
  if not oOOo0O00o . startswith ( '?' ) :
   i1I1iI = OOOOOoo0 . string
   if i1I1iI not in [ 'Parent Directory' , 'recycle_bin/' ] :
    if oOOo0O00o . endswith ( '/' ) :
     if browse :
      i1Iii1i1I ( i1I1iI , url + oOOo0O00o , 15 , iI111I11I1I1 , o0OO00oO , '' , '' , '' )
     else :
      i1Iii1i1I ( i1I1iI , url + oOOo0O00o , 14 , iI111I11I1I1 , o0OO00oO , '' , '' , '' )
    elif oOOo0O00o . endswith ( '.xml' ) :
     if browse :
      i1Iii1i1I ( i1I1iI , url + oOOo0O00o , 1 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
     else :
      if os . path . exists ( iIii1 ) == True :
       if i1I1iI in II11iiii1Ii :
        i1Iii1i1I ( i1I1iI + ' (in use)' , url + oOOo0O00o , 11 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
       else :
        i1Iii1i1I ( i1I1iI , url + oOOo0O00o , 11 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
      else :
       i1Iii1i1I ( i1I1iI , url + oOOo0O00o , 11 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
       if 8 - 8: o00ooo0
       if 49 - 49: Oo0ooO0oo0oO - IiiIIiiI11
def OoOOoOooooOOo ( browse = False ) :
 oOo0O = 'http://community-links.googlecode.com/svn/trunk/'
 O0O0ooOOO = BeautifulSoup ( IIII ( oOo0O ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 oo0O0 = O0O0ooOOO ( 'ul' ) [ 0 ] ( 'li' ) [ 1 : ]
 for OOOOOoo0 in oo0O0 :
  i1I1iI = OOOOOoo0 ( 'a' ) [ 0 ] [ 'href' ]
  if browse :
   i1Iii1i1I ( i1I1iI , oOo0O + i1I1iI , 1 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
  else :
   i1Iii1i1I ( i1I1iI , oOo0O + i1I1iI , 11 , iI111I11I1I1 , o0OO00oO , '' , '' , '' , '' , 'download' )
   if 22 - 22: o00 . oO * o00
   if 54 - 54: i1iIIi1 + oooOOOOO % o00ooo0 + OoOO - iiiiIi11i - Oo0oO0ooo
def I1i1Iiiii ( url , data = None ) :
 print 'getsoup' , url , data
 if url . startswith ( 'http://' ) or url . startswith ( 'https://' ) :
  data = IIII ( url )
  if re . search ( "#EXTM3U" , data ) or 'm3u' in url :
   print 'found m3u data' , data
   return data
   if 77 - 77: oO * o0O
 elif data == None :
  if xbmcvfs . exists ( url ) :
   if url . startswith ( "smb://" ) or url . startswith ( "nfs://" ) :
    oO00oOOoooO = xbmcvfs . copy ( url , os . path . join ( oo , 'temp' , 'sorce_temp.txt' ) )
    if oO00oOOoooO :
     data = open ( os . path . join ( oo , 'temp' , 'sorce_temp.txt' ) , "r" ) . read ( )
     xbmcvfs . delete ( os . path . join ( oo , 'temp' , 'sorce_temp.txt' ) )
    else :
     oOOO00o ( "failed to copy from smb:" )
   else :
    data = open ( url , 'r' ) . read ( )
    if re . match ( "#EXTM3U" , data ) or 'm3u' in url :
     print 'found m3u data' , data
     return data
  else :
   oOOO00o ( "Soup Data not found!" )
   return
 return BeautifulSOAP ( data , convertEntities = BeautifulStoneSoup . XML_ENTITIES )
 if 46 - 46: Oo0ooO0oo0oO - OoOO - IiiIIiiI11 * o0OO0
 if 34 - 34: IiiIIiiI11 - IiiIII111ii / oO + O0OOo * oooOOOOO
def OOoo0O0 ( url , fanart ) :
 print 'url-getData' , url
 OOOO0OoOO0o0o = "List"
 if 95 - 95: i11iIiiIii
 O0O0ooOOO = I1i1Iiiii ( url )
 if 32 - 32: oO
 if isinstance ( O0O0ooOOO , BeautifulSOAP ) :
  if len ( O0O0ooOOO ( 'layoutype' ) ) > 0 :
   OOOO0OoOO0o0o = "Thumbnail"
   if 42 - 42: i1iIIi1 * iiiiIi11i % I1iII1iiII . oO / Oo0oO0ooo
  if len ( O0O0ooOOO ( 'channels' ) ) > 0 :
   iII11I1IiiIi = O0O0ooOOO ( 'channel' )
   for oo0oO in iII11I1IiiIi :
    if 94 - 94: o0O / I1i1iI1i % IiiIII111ii * IiiIII111ii * o0OO0
    if 29 - 29: o00ooo0 + o00 / Oo0oO0ooo / oO * o0O
    O0OO = ''
    ii1iI1I11I = 0
    try :
     O0OO = oo0oO ( 'externallink' ) [ 0 ] . string
     ii1iI1I11I = len ( oo0oO ( 'externallink' ) )
    except : pass
    if 20 - 20: II1Iiii1111i / iiiiIi11i * Oo0oO0ooo - oOOO0OOooOoO0Oo % OoOO * i1iIIi1
    if ii1iI1I11I > 1 : O0OO = ''
    if 18 - 18: I1i1iI1i * oOOO0OOooOoO0Oo + oOOO0OOooOoO0Oo * i11iIiiIii * o0O - II
    i1I1iI = oo0oO ( 'name' ) [ 0 ] . string
    II11Iiii = oo0oO ( 'thumbnail' ) [ 0 ] . string
    if II11Iiii == None :
     II11Iiii = ''
     if 46 - 46: IiiIIiiI11 / oooOOOOO
    try :
     if not oo0oO ( 'fanart' ) :
      if i1IIi11111i . getSetting ( 'use_thumb' ) == "true" :
       O000 = II11Iiii
      else :
       O000 = fanart
     else :
      O000 = oo0oO ( 'fanart' ) [ 0 ] . string
     if O000 == None :
      raise
    except :
     O000 = fanart
     if 52 - 52: oO
    try :
     iiIi1IIi1I = oo0oO ( 'info' ) [ 0 ] . string
     if iiIi1IIi1I == None :
      raise
    except :
     iiIi1IIi1I = ''
     if 19 - 19: Oo0ooO0oo0oO
    try :
     o0o0o0oO0oOO = oo0oO ( 'genre' ) [ 0 ] . string
     if o0o0o0oO0oOO == None :
      raise
    except :
     o0o0o0oO0oOO = ''
     if 25 - 25: oooOOOOO / II
    try :
     o0OoOO000ooO0 = oo0oO ( 'date' ) [ 0 ] . string
     if o0OoOO000ooO0 == None :
      raise
    except :
     o0OoOO000ooO0 = ''
     if 31 - 31: oO . iiiiIi11i % Oo0ooO0oo0oO . Oo0oO0ooo + i1iIIi1
    try :
     credits = oo0oO ( 'credits' ) [ 0 ] . string
     if credits == None :
      raise
    except :
     credits = ''
     if 71 - 71: oOOO0OOooOoO0Oo . o0OO0
    try :
     if O0OO == '' :
      i1Iii1i1I ( i1I1iI . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 2 , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , credits , True )
     else :
      if i1I1iI == '[COLOR red]Live Sport[/COLOR]' :
       i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , O0OO . encode ( 'utf-8' ) , 31 , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , None , 'source' )
      else :
       i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , O0OO . encode ( 'utf-8' ) , 1 , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , None , 'source' )
    except :
     oOOO00o ( 'There was a problem adding directory from getData(): ' + i1I1iI . encode ( 'utf-8' , 'ignore' ) )
  else :
   oOOO00o ( 'No Channels: getItems' )
   oo0 ( O0O0ooOOO ( 'item' ) , fanart )
 else :
  oOOOoo00 ( O0O0ooOOO )
  if 9 - 9: iiiiIi11i % iiiiIi11i - Oo0oO0ooo
 if OOOO0OoOO0o0o == "Thumbnail" :
  OoO ( )
  if 12 - 12: iiiiIi11i - Oo0oO0ooo
def oOoO00O0 ( url , iconimage , fanart ) :
 i1Iii1i1I ( 'Furious Streams Playlisted' , url , 1 , iconimage , fanart , '' , '' , '' , None , 'source' )
 OOIi1iI111II1I1 = requests . get ( 'http://wizhdsports.is/' ) . content
 oOOOOoOO0o = re . compile ( '<ul class="sports_menu">(.+?)</ul>' , re . DOTALL ) . findall ( OOIi1iI111II1I1 )
 for i1II1 in oOOOOoOO0o :
  IIIii1II1II = re . compile ( '<a href="(.+?)".+?src="(.+?)".+?> (.+?)</li>' ) . findall ( str ( i1II1 ) )
  for i11i1IiiiiI1i1Iii , iconimage , i1I1iI in IIIii1II1II :
   i1I1iI = i1I1iI . title ( )
   if i1I1iI == 'Nfl' : oo0OooOOo0 = OO0o
   elif i1I1iI == 'Football' : oo0OooOOo0 = Oo0Ooo
   elif i1I1iI == 'Cricket' : oo0OooOOo0 = O0O0OO0O0O0
   elif i1I1iI == 'Tennis' : oo0OooOOo0 = iiiii
   elif i1I1iI == 'Boxing' : oo0OooOOo0 = ooo0OO
   elif i1I1iI == 'Golf' : oo0OooOOo0 = II1
   elif i1I1iI == 'Motosports' : oo0OooOOo0 = O00ooooo00
   elif i1I1iI == 'Rugby' : oo0OooOOo0 = I1IiiI
   elif i1I1iI == 'Hockey' : oo0OooOOo0 = IIi1IiiiI1Ii
   elif i1I1iI == 'Nba' : oo0OooOOo0 = I11i11Ii
   elif i1I1iI == 'Darts' : oo0OooOOo0 = oO00oOo
   elif i1I1iI == 'Wwe' : oo0OooOOo0 = OOOo0
   elif i1I1iI == 'Horse Racing' : oo0OooOOo0 = Oooo000o
   elif i1I1iI == 'Ufc' : oo0OooOOo0 = IiIi11iIIi1Ii
   elif i1I1iI == 'Baseball' : oo0OooOOo0 = Oo0O
   if i1I1iI == 'Tv Shows' : pass
   elif i1I1iI == 'Others' : pass
   elif i1I1iI == 'P2P Online' : pass
   else :
    if oo0OooOOo0 == '' :
     oo0OooOOo0 = iconimage
    i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , i11i1IiiiiI1i1Iii . encode ( 'utf-8' ) , 32 , oo0OooOOo0 , fanart , '' , '' , '' , None , 'source' )
    if 87 - 87: Oo0oO0ooo
def IiI1iiiIii ( url ) :
 I1III1111iIi = [ ]
 if 38 - 38: IiiIII111ii + IiiIIiiI11 / oOOO0OOooOoO0Oo % II - O0OOo
 from datetime import datetime
 iI11 = datetime . now ( ) . strftime ( '%d' )
 Ii1Io0OO0o0o00o = datetime . now ( ) . strftime ( '%m' )
 oOo0 = datetime . now ( ) . strftime ( '%Y' )
 OOOoOO = datetime . now ( ) . strftime ( '%H' )
 I11IIIi = datetime . now ( ) . strftime ( '%M' )
 iIIiiI1II1i11 = iI11 + '-' + Ii1Io0OO0o0o00o + '-' + oOo0
 OOIi1iI111II1I1 = requests . get ( url ) . content
 oOOOOoOO0o = re . compile ( '<h3>.+?Games On : (.+?)</h3>(.+?)<li class=\'sports_red_bar\'>' , re . DOTALL ) . findall ( OOIi1iI111II1I1 )
 for o0OoOO000ooO0 , o0o0 in oOOOOoOO0o :
  if o0OoOO000ooO0 == iIIiiI1II1i11 :
   IIIii1II1II = re . compile ( '<div class=\'col-md-2\'>.+?</span>(.+?)</div>.+?<div class=\'col-md-6\'>(.+?)</div>.+?div class="card-block drop_box">(.+?)<div class="card">' , re . DOTALL ) . findall ( str ( o0o0 ) )
   for time , IIii1111 , I1iI in IIIii1II1II :
    IIIIiIiIi1 = len ( IIIii1II1II )
    IIii1111 = IIii1111 . replace ( '  ' , '' ) . replace ( '	' , '' )
    I1iI = I1iI . replace ( '  ' , '' )
    I11iiiiI1i = re . findall ( '(.+?):(.+?)-(.+?):(.+?)>' , str ( time + '>' ) )
    for iI1i11 , OoOOoooOO0O , ooo00Ooo , Oo0o0O00 in I11iiiiI1i :
     ii1 = int ( iI1i11 ) * 24 + int ( OoOOoooOO0O )
     I1i11 = int ( ooo00Ooo ) * 24 + int ( Oo0o0O00 )
     OOo0O0oo0OO0O = int ( OOOoOO ) * 24 + int ( I11IIIi )
     if I1i11 > OOo0O0oo0OO0O > ii1 :
      i1I1iI = '[COLORgreen]' + IIii1111 + '[/COLOR]'
     else :
      i1I1iI = IIii1111
    OO0 = re . compile ( "<a href='(.+?)'>.+?>(.+?)</div></a>" ) . findall ( str ( I1iI ) )
    for o00oOO0 , o0Oooo in OO0 :
     o00oOO0 = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + o00oOO0
     if len ( OO0 ) > 1 :
      I1III1111iIi . append ( ( o00oOO0 , o0Oooo ) )
     else :
      oO0Oo ( o00oOO0 , time . replace ( ' ' , '' ) + '-' + i1I1iI . encode ( 'utf-8' , 'ignore' ) , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , True , None , iiI , IIIIiIiIi1 )
    if len ( I1III1111iIi ) > 1 :
     oOIIiIi = str ( I1III1111iIi ) . replace ( '[' , 'sublink' ) . replace ( ']' , '#' ) . replace ( 'sublink(\'' , 'sublink:' ) . replace ( 'plugin:' , 'LISTSOURCE:plugin:' ) . replace ( "', '" , '::LISTNAME:' ) . replace ( "'), ('" , '::#sublink' ) . replace ( "')" , '' ) . replace ( 'sublinkLISTSOURCE' , 'sublink:LISTSOURCE' )
     xbmc . log ( oOIIiIi )
     i1Iii1i1I ( time . replace ( ' ' , '' ) + '-' + i1I1iI , oOIIiIi , 30 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
     del I1III1111iIi [ : ]
     if 91 - 91: O0OOo * I1i1iI1i / Oo0ooO0oo0oO . iiiiIi11i + o00ooo0 + o00
     if 8 - 8: II1Iiii1111i / O0OOo
     if 20 - 20: Oo0ooO0oo0oO
     if 95 - 95: IiiIII111ii - Oo0ooO0oo0oO
     if 34 - 34: II * Oo0ooO0oo0oO . I1iII1iiII * II / II
     if 30 - 30: O0OOo + I1i1iI1i / I1i1iI1i % O0OOo . O0OOo
     if 55 - 55: II - IiiIIiiI11 + o0OO0 + IiiIII111ii % oooOOOOO
def oOOOoo00 ( data ) :
 iiI11i1II = data . rstrip ( )
 IIIii1II1II = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)' ) . findall ( iiI11i1II )
 IIIIiIiIi1 = len ( IIIii1II1II )
 print 'total m3u links' , IIIIiIiIi1
 for OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 in IIIii1II1II :
  if 'tvg-logo' in OO0O0OOo0O :
   II11Iiii = iiIII1i ( OO0O0OOo0O , 'tvg-logo=[\'"](.*?)[\'"]' )
   if II11Iiii :
    if II11Iiii . startswith ( 'http' ) :
     II11Iiii = II11Iiii
     if 31 - 31: IiiIII111ii . oO - II . OoOO / OoOO
    elif not i1IIi11111i . getSetting ( 'logo-folderPath' ) == "" :
     OOoO = i1IIi11111i . getSetting ( 'logo-folderPath' )
     II11Iiii = OOoO + II11Iiii
     if 44 - 44: II1Iiii1111i
    else :
     II11Iiii = II11Iiii
     if 20 - 20: IiiIIiiI11 + oooOOOOO / iiiiIi11i % o0O
     if 88 - 88: o00 / o0OO0
  else :
   II11Iiii = ''
  if 'type' in OO0O0OOo0O :
   OOOOO0O00 = iiIII1i ( OO0O0OOo0O , 'type=[\'"](.*?)[\'"]' )
   if OOOOO0O00 == 'yt-dl' :
    OOooO0o0 = OOooO0o0 + "&mode=18"
   elif OOOOO0O00 == 'regex' :
    oOo0O = OOooO0o0 . split ( '&regexs=' )
    if 30 - 30: o0O . Oo0ooO0oo0oO . oO / Oo0oO0ooo
    iiI = iiI1I1 ( I1i1Iiiii ( '' , data = oOo0O [ 1 ] ) )
    if 56 - 56: Oo0ooO0oo0oO . iiiiIi11i + I1i1iI1i
    oO0Oo ( oOo0O [ 0 ] , I1o0OooOOOOOO , II11Iiii , '' , '' , '' , '' , '' , None , iiI , IIIIiIiIi1 )
    continue
  oO0Oo ( OOooO0o0 , I1o0OooOOOOOO , II11Iiii , '' , '' , '' , '' , '' , None , '' , IIIIiIiIi1 )
  if 1 - 1: IiiIII111ii
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 if 97 - 97: oO + IiiIII111ii + iiiiIi11i + i11iIiiIii
def oOoO0 ( name , url , fanart ) :
 O0O0ooOOO = I1i1Iiiii ( url )
 Oo0 = O0O0ooOOO . find ( 'channel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 oo0O0o00o0O = Oo0 ( 'item' )
 try :
  O000 = Oo0 ( 'fanart' ) [ 0 ] . string
  if O000 == None :
   raise
 except :
  O000 = fanart
 for oo0oO in Oo0 ( 'subchannel' ) :
  name = oo0oO ( 'name' ) [ 0 ] . string
  try :
   II11Iiii = oo0oO ( 'thumbnail' ) [ 0 ] . string
   if II11Iiii == None :
    raise
  except :
   II11Iiii = ''
  try :
   if not oo0oO ( 'fanart' ) :
    if i1IIi11111i . getSetting ( 'use_thumb' ) == "true" :
     O000 = II11Iiii
   else :
    O000 = oo0oO ( 'fanart' ) [ 0 ] . string
   if O000 == None :
    raise
  except :
   pass
  try :
   iiIi1IIi1I = oo0oO ( 'info' ) [ 0 ] . string
   if iiIi1IIi1I == None :
    raise
  except :
   iiIi1IIi1I = ''
   if 35 - 35: II + I1iII1iiII % O0OOo % IiiIIiiI11 + II1Iiii1111i
  try :
   o0o0o0oO0oOO = oo0oO ( 'genre' ) [ 0 ] . string
   if o0o0o0oO0oOO == None :
    raise
  except :
   o0o0o0oO0oOO = ''
   if 17 - 17: I1iII1iiII
  try :
   o0OoOO000ooO0 = oo0oO ( 'date' ) [ 0 ] . string
   if o0OoOO000ooO0 == None :
    raise
  except :
   o0OoOO000ooO0 = ''
   if 21 - 21: I1i1iI1i
  try :
   credits = oo0oO ( 'credits' ) [ 0 ] . string
   if credits == None :
    raise
  except :
   credits = ''
   if 29 - 29: IiiIIiiI11 / o0OO0 / II * oO
  try :
   i1Iii1i1I ( name . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 3 , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , credits , o0OoOO000ooO0 )
  except :
   oOOO00o ( 'There was a problem adding directory - ' + name . encode ( 'utf-8' , 'ignore' ) )
 oo0 ( oo0O0o00o0O , O000 )
 if 10 - 10: oOOO0OOooOoO0Oo % i1iIIi1 * i1iIIi1 . IiiIIiiI11 / oooOOOOO % oO
 if 49 - 49: o00ooo0 / II1Iiii1111i + iiiiIi11i * Oo0oO0ooo
def I1ii11 ( name , url , fanart ) :
 O0O0ooOOO = I1i1Iiiii ( url )
 Oo0 = O0O0ooOOO . find ( 'subchannel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 oo0O0o00o0O = Oo0 ( 'subitem' )
 oo0 ( oo0O0o00o0O , fanart )
 if 74 - 74: I1i1iI1i - Oo0oO0ooo . I1iII1iiII
 if 43 - 43: IiiIII111ii / Oo0ooO0oo0oO
def OO0oo0O ( name , url , iconimage , fanart ) :
 xbmc . log ( 'I GOT HERE###############' )
 I1III1111iIi = [ ] ; Ii1i1iI = [ ] ; IIiI1 = 0
 i1iI1 = ii1I1IiiI1ii1i ( url , 'sublink:' , '#' )
 for O0o in i1iI1 :
  if 'LISTSOURCE:' in O0o :
   oOIIiIi = oO0OoO00o ( O0o , 'LISTSOURCE:' , '::' )
   II1iiiiII = oO0OoO00o ( O0o , 'LISTNAME:' , '::' )
  else :
   oOIIiIi = O0o . replace ( 'sublink:' , '' ) . replace ( '#' , '' )
   II1iiiiII = name
  if len ( oOIIiIi ) > 10 :
   IIiI1 = IIiI1 + 1 ; I1III1111iIi . append ( II1iiiiII ) ; Ii1i1iI . append ( oOIIiIi )
   if 61 - 61: IiiIII111ii % Oo0ooO0oo0oO - Oo0oO0ooo - o0OO0 % iiiiIi11i
 if IIiI1 == 1 :
  try :
   if 90 - 90: o0O + O0OOo + II - oOOO0OOooOoO0Oo * i1iIIi1 . O0OOo
   I11iiiii1II = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; I11iiiii1II . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
   ooOOooOo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Ii1i1iI [ 0 ] , listitem = I11iiiii1II )
   xbmc . Player ( ) . play ( I1i111iiIIIi ( Ii1i1iI [ 0 ] ) , I11iiiii1II )
  except :
   pass
 else :
  O00 = xbmcgui . Dialog ( )
  I11ii1i1 = O00 . select ( 'Furious Streams Select A Source' , I1III1111iIi )
  if I11ii1i1 >= 0 :
   ooo0OoOOOOO = name
   i1iIi1iI = str ( Ii1i1iI [ I11ii1i1 ] )
   if 39 - 39: oOOO0OOooOoO0Oo
   try :
    xbmc . Player ( ) . play ( I1i111iiIIIi ( i1iIi1iI ) , xbmcgui . ListItem ( ooo0OoOOOOO ) )
   except :
    xbmc . Player ( ) . play ( i1iIi1iI , xbmcgui . ListItem ( ooo0OoOOOOO ) )
    if 86 - 86: IiiIIiiI11 * Oo0ooO0oo0oO + IiiIIiiI11 + o0OO0
    if 8 - 8: oOOO0OOooOoO0Oo - IiiIII111ii / II
def oo0oOoo ( ) :
 if 57 - 57: o00 - O0OOo
 I11i = 'Name of channel show or movie'
 iI11o00oOoOo0 = ''
 oO0Oo0O0o = xbmc . Keyboard ( iI11o00oOoOo0 , I11i )
 oO0Oo0O0o . doModal ( )
 if oO0Oo0O0o . isConfirmed ( ) :
  iI11o00oOoOo0 = oO0Oo0O0o . getText ( ) . replace ( '\n' , '' ) . strip ( )
  if len ( iI11o00oOoOo0 ) == 0 :
   xbmcgui . Dialog ( ) . ok ( 'RobinHood' , 'Nothing Entered' )
   return
   if 72 - 72: oOOO0OOooOoO0Oo
 iI11o00oOoOo0 = iI11o00oOoOo0 . lower ( )
 I1III1111iIi = [ ]
 I1III1111iIi . append ( _Edit . MainBase )
 OO0ooo0oOO = 0
 oo000 = 1
 ii = 0
 OoOIiiiii111i1ii = 0
 i1i1iII1 = xbmcgui . DialogProgress ( )
 i1i1iII1 . create ( 'Furious Streams Searching Please wait' , ' ' )
 if 25 - 25: o0O % IiiIII111ii . II
 while oo000 <> ii :
  IIIIi1 = I1III1111iIi [ ii ] . strip ( )
  print 'read this one from file list (' + str ( ii ) + ')'
  ii = ii + 1
  if 3 - 3: oOOO0OOooOoO0Oo
  i1iiIiI1Ii1i = ''
  try :
   i1iiIiI1Ii1i = net . http_GET ( IIIIi1 ) . content
   i1iiIiI1Ii1i = i1iiIiI1Ii1i . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
   if 22 - 22: i1iIIi1 / i11iIiiIii
  except :
   pass
   if 62 - 62: o00ooo0 / O0OOo
  if len ( i1iiIiI1Ii1i ) < 10 :
   i1iiIiI1Ii1i = ''
   OO0ooo0oOO = OO0ooo0oOO + 1
   print '*** PASSED ****' + IIIIi1 + '  ************* Total Passed Urls: ' + str ( OO0ooo0oOO )
   time . sleep ( .5 )
   if 7 - 7: OoOO . i1iIIi1
  O000OOO0OOo = int ( ( ii / 300 ) * 100 )
  i1i1I111iIi1 = '     Pages Read: ' + str ( ii ) + '        Matches Found: ' + str ( OoOIiiiii111i1ii )
  i1i1iII1 . update ( O000OOO0OOo , "" , i1i1I111iIi1 , "" )
  if 92 - 92: II
  if i1i1iII1 . iscanceled ( ) :
   return
   if 22 - 22: I1i1iI1i % IiiIII111ii * O0OOo / oO % i11iIiiIii * IiiIIiiI11
  if len ( i1iiIiI1Ii1i ) > 10 :
   Oo00OoOo = ii1I1IiiI1ii1i ( i1iiIiI1Ii1i , '<channel>' , '</channel>' )
   for O0o in Oo00OoOo :
    oOIIiIi = oO0OoO00o ( O0o , '<externallink>' , '</externallink>' )
    if 24 - 24: i11iIiiIii - oOOO0OOooOoO0Oo
    if 21 - 21: IiiIIiiI11
    if len ( oOIIiIi ) > 5 :
     oo000 = oo000 + 1
     I1III1111iIi . append ( oOIIiIi )
     if 92 - 92: i11iIiiIii / oOOO0OOooOoO0Oo - IiiIII111ii % II * oOOO0OOooOoO0Oo + I1i1iI1i
     if 11 - 11: OoOO . oOOO0OOooOoO0Oo
   Oo0000oOo = ii1I1IiiI1ii1i ( i1iiIiI1Ii1i , '<item>' , '</item>' )
   for O0o in Oo0000oOo :
    oOIIiIi = oO0OoO00o ( O0o , '<link>' , '</link>' )
    i1I1iI = oO0OoO00o ( O0o , '<title>' , '</title>' )
    I11 = '  ' + i1I1iI . lower ( ) + '  '
    if 95 - 95: II * II1Iiii1111i . oOOO0OOooOoO0Oo
    if len ( oOIIiIi ) > 5 and I11 . find ( iI11o00oOoOo0 ) > 0 :
     OoOIiiiii111i1ii = OoOIiiiii111i1ii + 1
     o0OO00oO = ''
     II11Iiii = oO0OoO00o ( O0o , '<thumbnail>' , '</thumbnail>' )
     o0OO00oO = oO0OoO00o ( O0o , '<fanart>' , '</fanart>' )
     if len ( o0OO00oO ) < 5 :
      o0OO00oO = iI111I11I1I1
     if oOIIiIi . find ( 'sublink' ) > 0 :
      i1Iii1i1I ( i1I1iI , oOIIiIi , 30 , II11Iiii , o0OO00oO , '' , '' , '' , '' )
     else :
      oO0Oo ( str ( oOIIiIi ) , i1I1iI , II11Iiii , o0OO00oO , '' , '' , '' , True , None , '' , 1 )
      if 97 - 97: oOOO0OOooOoO0Oo - o0O
      if 75 - 75: OoOO * i1iIIi1
 i1i1iII1 . close ( )
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 if 9 - 9: i1iIIi1 - o0OO0 + iiiiIi11i / o0O / i11iIiiIii
def I1IIIiI1I1ii1 ( data , Searchkey ) :
 iiI11i1II = data . rstrip ( )
 IIIii1II1II = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)' ) . findall ( iiI11i1II )
 IIIIiIiIi1 = len ( IIIii1II1II )
 print 'total m3u links' , IIIIiIiIi1
 for OO0O0OOo0O , I1o0OooOOOOOO , OOooO0o0 in IIIii1II1II :
  if 'tvg-logo' in OO0O0OOo0O :
   II11Iiii = iiIII1i ( OO0O0OOo0O , 'tvg-logo=[\'"](.*?)[\'"]' )
   if II11Iiii :
    if II11Iiii . startswith ( 'http' ) :
     II11Iiii = II11Iiii
     if 30 - 30: iiiiIi11i * OoOO
    elif not i1IIi11111i . getSetting ( 'logo-folderPath' ) == "" :
     OOoO = i1IIi11111i . getSetting ( 'logo-folderPath' )
     II11Iiii = OOoO + II11Iiii
     if 38 - 38: i1iIIi1 - O0OOo . o00 - oOOO0OOooOoO0Oo . OoOO
    else :
     II11Iiii = II11Iiii
     if 89 - 89: o0O
     if 21 - 21: IiiIIiiI11 % IiiIIiiI11
  else :
   II11Iiii = ''
  if 'type' in OO0O0OOo0O :
   OOOOO0O00 = iiIII1i ( OO0O0OOo0O , 'type=[\'"](.*?)[\'"]' )
   if OOOOO0O00 == 'yt-dl' :
    OOooO0o0 = OOooO0o0 + "&mode=18"
   elif OOOOO0O00 == 'regex' :
    oOo0O = OOooO0o0 . split ( '&regexs=' )
    if 27 - 27: i11iIiiIii / O0OOo
    iiI = iiI1I1 ( I1i1Iiiii ( '' , data = oOo0O [ 1 ] ) )
    if 84 - 84: I1i1iI1i
    oO0Oo ( oOo0O [ 0 ] , I1o0OooOOOOOO , II11Iiii , '' , '' , '' , '' , '' , None , iiI , IIIIiIiIi1 )
    continue
  oO0Oo ( OOooO0o0 , I1o0OooOOOOOO , II11Iiii , '' , '' , '' , '' , '' , None , '' , IIIIiIiIi1 )
  if 43 - 43: II1Iiii1111i - OoOO
def ii1iI ( text , pattern ) :
 IIi = ""
 try :
  ooOooo0 = re . findall ( pattern , text , flags = re . DOTALL )
  IIi = ooOooo0 [ 0 ]
 except :
  IIi = ""
  if 67 - 67: Oo0ooO0oo0oO
 return IIi
 if 55 - 55: O0OOo - IiiIII111ii * Oo0oO0ooo + o00 * o00 * iiiiIi11i
def ii1I1IiiI1ii1i ( text , start_with , end_with ) :
 O000Oo0o = re . findall ( "(?i)(" + start_with + "[\S\s]+?" + end_with + ")" , text )
 return O000Oo0o
 if 99 - 99: o0O % II + II + IiiIII111ii - oOOO0OOooOoO0Oo / oOOO0OOooOoO0Oo
def oO0OoO00o ( text , from_string , to_string , excluding = True ) :
 if excluding :
  try : O000Oo0o = re . search ( "(?i)" + from_string + "([\S\s]+?)" + to_string , text ) . group ( 1 )
  except : O000Oo0o = ''
 else :
  try : O000Oo0o = re . search ( "(?i)(" + from_string + "[\S\s]+?" + to_string + ")" , text ) . group ( 1 )
  except : O000Oo0o = ''
 return O000Oo0o
 if 7 - 7: Oo0ooO0oo0oO + o00 / i1iIIi1
def oo0 ( items , fanart ) :
 IIIIiIiIi1 = len ( items )
 print 'START GET ITEMS *****'
 oOOO00o ( 'Total Items: %s' % IIIIiIiIi1 )
 for i1II1 in items :
  OOOoO000 = False
  oOOOO = False
  try :
   i1I1iI = i1II1 ( 'title' ) [ 0 ] . string
   if i1I1iI is None :
    i1I1iI = 'unknown?'
  except :
   oOOO00o ( 'Name Error' )
   i1I1iI = ''
   if 49 - 49: o0OO0 . II1Iiii1111i . i11iIiiIii % i1iIIi1
   if 34 - 34: oOOO0OOooOoO0Oo % i1iIIi1
  try :
   if i1II1 ( 'epg' ) :
    if i1II1 . epg_url :
     oOOO00o ( 'Get EPG Regex' )
     IiI1i = i1II1 . epg_url . string
     oO0oOOoo00000 = i1II1 . epg_regex . string
     oOo00 = i1iI11i1IIi ( IiI1i , oO0oOOoo00000 )
     if oOo00 :
      i1I1iI += ' - ' + oOo00
    elif i1II1 ( 'epg' ) [ 0 ] . string > 1 :
     i1I1iI += ii1IIi111 ( i1II1 ( 'epg' ) [ 0 ] . string )
   else :
    pass
  except :
   oOOO00o ( 'EPG Error' )
  try :
   oOo0O = [ ]
   if len ( i1II1 ( 'link' ) ) > 0 :
    if 29 - 29: O0OOo . i1iIIi1 * II1Iiii1111i
    for OOOOOoo0 in i1II1 ( 'link' ) :
     if not OOOOOoo0 . string == None :
      oOo0O . append ( OOOOOoo0 . string )
      if 68 - 68: i11iIiiIii + oooOOOOO
   elif len ( i1II1 ( 'sportsdevil' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'sportsdevil' ) :
     if not OOOOOoo0 . string == None :
      oOOoo0o0OOOO = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + OOOOOoo0 . string
      i1IiII1III = i1II1 ( 'referer' ) [ 0 ] . string
      if i1IiII1III :
       if 30 - 30: iiiiIi11i
       oOOoo0o0OOOO = oOOoo0o0OOOO + '%26referer=' + i1IiII1III
      oOo0O . append ( oOOoo0o0OOOO )
   elif len ( i1II1 ( 'p2p' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'p2p' ) :
     if not OOOOOoo0 . string == None :
      if 'sop://' in OOOOOoo0 :
       Oo00oo0000OO = 'plugin://plugin.video.p2p-streams/?url=' + OOOOOoo0 . string + '&amp;mode=2&amp;' + 'name=' + i1I1iI
       oOo0O . append ( Oo00oo0000OO )
      else :
       O0oOOo0Oo = 'plugin://plugin.video.p2p-streams/?url=' + OOOOOoo0 . string + '&amp;mode=1&amp;' + 'name=' + i1I1iI
       oOo0O . append ( O0oOOo0Oo )
   elif len ( i1II1 ( 'vaughn' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'vaughn' ) :
     if not OOOOOoo0 . string == None :
      o000O000 = 'plugin://plugin.stream.vaughnlive.tv/?mode=PlayLiveStream&amp;channel=' + OOOOOoo0 . string
      oOo0O . append ( o000O000 )
   elif len ( i1II1 ( 'ilive' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'ilive' ) :
     if not OOOOOoo0 . string == None :
      if not 'http' in OOOOOoo0 . string :
       ii1oOoO0o0ooo = 'plugin://plugin.video.tbh.ilive/?url=http://www.streamlive.to/view/' + OOOOOoo0 . string + '&amp;link=99&amp;mode=iLivePlay'
      else :
       ii1oOoO0o0ooo = 'plugin://plugin.video.tbh.ilive/?url=' + OOOOOoo0 . string + '&amp;link=99&amp;mode=iLivePlay'
   elif len ( i1II1 ( 'yt-dl' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'yt-dl' ) :
     if not OOOOOoo0 . string == None :
      oO0o0O0Ooo0o = OOOOOoo0 . string + '&mode=18'
      oOo0O . append ( oO0o0O0Ooo0o )
   elif len ( i1II1 ( 'utube' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'utube' ) :
     if not OOOOOoo0 . string == None :
      if len ( OOOOOoo0 . string ) == 11 :
       i1Ii11II = 'plugin://plugin.video.youtube/play/?video_id=' + OOOOOoo0 . string
      elif OOOOOoo0 . string . startswith ( 'PL' ) and not '&order=' in OOOOOoo0 . string :
       i1Ii11II = 'plugin://plugin.video.youtube/play/?&order=default&playlist_id=' + OOOOOoo0 . string
      else :
       i1Ii11II = 'plugin://plugin.video.youtube/play/?playlist_id=' + OOOOOoo0 . string
    oOo0O . append ( i1Ii11II )
   elif len ( i1II1 ( 'imdb' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'imdb' ) :
     if not OOOOOoo0 . string == None :
      if i1IIi11111i . getSetting ( 'genesisorpulsar' ) == '0' :
       IioO0oOOO0Ooo = 'plugin://plugin.video.genesis/?action=play&imdb=' + OOOOOoo0 . string
      else :
       IioO0oOOO0Ooo = 'plugin://plugin.video.pulsar/movie/tt' + OOOOOoo0 . string + '/play'
      oOo0O . append ( IioO0oOOO0Ooo )
   elif len ( i1II1 ( 'f4m' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'f4m' ) :
     if not OOOOOoo0 . string == None :
      if '.f4m' in OOOOOoo0 . string :
       i1i1I = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( OOOOOoo0 . string )
      elif '.m3u8' in OOOOOoo0 . string :
       i1i1I = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( OOOOOoo0 . string ) + '&amp;streamtype=HLS'
       if 25 - 25: o0O + O0OOo + IiiIII111ii / o0OO0 / IiiIIiiI11
      else :
       i1i1I = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( OOOOOoo0 . string ) + '&amp;streamtype=SIMPLE'
    oOo0O . append ( i1i1I )
   elif len ( i1II1 ( 'ftv' ) ) > 0 :
    for OOOOOoo0 in i1II1 ( 'ftv' ) :
     if not OOOOOoo0 . string == None :
      o0O0Oo00Oo0o = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( i1I1iI ) + '&url=' + OOOOOoo0 . string + '&mode=125&ch_fanart=na'
     oOo0O . append ( o0O0Oo00Oo0o )
   if len ( oOo0O ) < 1 :
    raise
  except :
   oOOO00o ( 'Error <link> element, Passing:' + i1I1iI . encode ( 'utf-8' , 'ignore' ) )
   continue
   if 74 - 74: I1i1iI1i / i11iIiiIii - o0OO0 * Oo0oO0ooo
  OOOoO000 = False
  if 5 - 5: oO - oO . I1i1iI1i + o00 - oO . II1Iiii1111i
  try :
   OOOoO000 = i1II1 ( 'externallink' ) [ 0 ] . string
  except : pass
  if 31 - 31: o0OO0 - o0O - o0O % IiiIIiiI11
  if OOOoO000 :
   iii = [ OOOoO000 ]
   OOOoO000 = True
  else :
   OOOoO000 = False
  try :
   oOOOO = i1II1 ( 'jsonrpc' ) [ 0 ] . string
  except : pass
  if oOOOO :
   iii = [ oOOOO ]
   oOOOO = True
  else :
   oOOOO = False
  try :
   II11Iiii = i1II1 ( 'thumbnail' ) [ 0 ] . string
   if II11Iiii == None :
    raise
  except :
   II11Iiii = ''
  try :
   if not i1II1 ( 'fanart' ) :
    if i1IIi11111i . getSetting ( 'use_thumb' ) == "true" :
     O000 = II11Iiii
    else :
     O000 = fanart
   else :
    O000 = i1II1 ( 'fanart' ) [ 0 ] . string
   if O000 == None :
    raise
  except :
   O000 = fanart
  try :
   iiIi1IIi1I = i1II1 ( 'info' ) [ 0 ] . string
   if iiIi1IIi1I == None :
    raise
  except :
   iiIi1IIi1I = ''
   if 27 - 27: IiiIIiiI11 / i11iIiiIii / I1iII1iiII + oOOO0OOooOoO0Oo
  try :
   o0o0o0oO0oOO = i1II1 ( 'genre' ) [ 0 ] . string
   if o0o0o0oO0oOO == None :
    raise
  except :
   o0o0o0oO0oOO = ''
   if 34 - 34: oO
  try :
   o0OoOO000ooO0 = i1II1 ( 'date' ) [ 0 ] . string
   if o0OoOO000ooO0 == None :
    raise
  except :
   o0OoOO000ooO0 = ''
   if 91 - 91: o0O % Oo0oO0ooo . o0O % I1iII1iiII / o0OO0 * o00
  iiI = None
  if i1II1 ( 'regex' ) :
   try :
    iioo0o0OoOOO = i1II1 ( 'regex' )
    iiI = iiI1I1 ( iioo0o0OoOOO )
   except :
    pass
    if 88 - 88: IiiIII111ii
  try :
   if len ( oOo0O ) > 1 :
    if 19 - 19: o0OO0 * i1iIIi1 + oooOOOOO
    O0ooO00oO = 0
    i11i1iIiii = [ ]
    for OOOOOoo0 in oOo0O :
     if i1IIi11111i . getSetting ( 'ask_playlist_items' ) == 'true' :
      if iiI :
       i11i1iIiii . append ( OOOOOoo0 + '&regexs=' + iiI )
      elif any ( x in OOOOOoo0 for x in iI1Ii11111iIi ) and OOOOOoo0 . startswith ( 'http' ) :
       i11i1iIiii . append ( OOOOOoo0 + '&mode=19' )
     else :
      i11i1iIiii . append ( OOOOOoo0 )
    if i1IIi11111i . getSetting ( 'add_playlist' ) == "false" :
     for OOOOOoo0 in oOo0O :
      O0ooO00oO += 1
      print 'ADDLINK 1'
      oO0Oo ( OOOOOoo0 , '%s) %s' % ( O0ooO00oO , i1I1iI . encode ( 'utf-8' , 'ignore' ) ) , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , True , i11i1iIiii , iiI , IIIIiIiIi1 )
    else :
     oO0Oo ( '' , i1I1iI . encode ( 'utf-8' , 'ignore' ) , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , True , i11i1iIiii , iiI , IIIIiIiIi1 )
   else :
    if OOOoO000 :
     i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , iii [ 0 ] . encode ( 'utf-8' ) , 1 , II11Iiii , fanart , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , None , 'source' )
    elif oOOOO :
     i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , iii [ 0 ] , 53 , II11Iiii , fanart , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , None , 'source' )
    elif oOo0O [ 0 ] . find ( 'sublink' ) > 0 :
     i1Iii1i1I ( i1I1iI . encode ( 'utf-8' ) , oOo0O [ 0 ] , 30 , II11Iiii , fanart , '' , '' , '' , '' )
     if 71 - 71: O0OOo % II - Oo0ooO0oo0oO % IiiIIiiI11 - iiiiIi11i
    else :
     oO0Oo ( oOo0O [ 0 ] , i1I1iI . encode ( 'utf-8' , 'ignore' ) , II11Iiii , O000 , iiIi1IIi1I , o0o0o0oO0oOO , o0OoOO000ooO0 , True , None , iiI , IIIIiIiIi1 )
     if 67 - 67: oO + I1i1iI1i
     if 84 - 84: iiiiIi11i * OoOO - i1iIIi1 * i1iIIi1
  except :
   oOOO00o ( 'There was a problem adding item - ' + i1I1iI . encode ( 'utf-8' , 'ignore' ) )
 print 'FINISH GET ITEMS *****'
 if 8 - 8: II / I1iII1iiII . II1Iiii1111i
def iiI1I1 ( reg_item ) :
 try :
  iiI = { }
  for OOOOOoo0 in reg_item :
   iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] = { }
   if 41 - 41: IiiIII111ii + o00ooo0
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'expre' ] = OOOOOoo0 ( 'expres' ) [ 0 ] . string
    if not iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'expre' ] :
     iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'expre' ] = ''
   except :
    oOOO00o ( "Regex: -- No Referer --" )
   iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'page' ] = OOOOOoo0 ( 'page' ) [ 0 ] . string
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'refer' ] = OOOOOoo0 ( 'referer' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No Referer --" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'connection' ] = OOOOOoo0 ( 'connection' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No connection --" )
    if 86 - 86: o00 . o0O - o00ooo0
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'notplayable' ] = OOOOOoo0 ( 'notplayable' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No notplayable --" )
    if 56 - 56: iiiiIi11i
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'noredirect' ] = OOOOOoo0 ( 'noredirect' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No noredirect --" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'origin' ] = OOOOOoo0 ( 'origin' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No origin --" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'includeheaders' ] = OOOOOoo0 ( 'includeheaders' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No includeheaders --" )
    if 61 - 61: Oo0oO0ooo / oO / I1i1iI1i * iiiiIi11i
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'x-req' ] = OOOOOoo0 ( 'x-req' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No x-req --" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'x-forward' ] = OOOOOoo0 ( 'x-forward' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No x-forward --" )
    if 23 - 23: II1Iiii1111i - oO + IiiIIiiI11
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'agent' ] = OOOOOoo0 ( 'agent' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- No User Agent --" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'post' ] = OOOOOoo0 ( 'post' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a post" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'rawpost' ] = OOOOOoo0 ( 'rawpost' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a rawpost" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'htmlunescape' ] = OOOOOoo0 ( 'htmlunescape' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a htmlunescape" )
    if 12 - 12: Oo0ooO0oo0oO / II % Oo0oO0ooo / i11iIiiIii % OoOO
    if 15 - 15: o0O % OoOO - I1i1iI1i * oooOOOOO + IiiIIiiI11
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'readcookieonly' ] = OOOOOoo0 ( 'readcookieonly' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a readCookieOnly" )
    if 11 - 11: IiiIII111ii * oooOOOOO - o00
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = OOOOOoo0 ( 'cookiejar' ) [ 0 ] . string
    if not iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] :
     iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = ''
   except :
    oOOO00o ( "Regex: -- Not a cookieJar" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'setcookie' ] = OOOOOoo0 ( 'setcookie' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a setcookie" )
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'appendcookie' ] = OOOOOoo0 ( 'appendcookie' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- Not a appendcookie" )
    if 66 - 66: o00 . i11iIiiIii - IiiIII111ii * Oo0oO0ooo + OoOO * O0OOo
   try :
    iiI [ OOOOOoo0 ( 'name' ) [ 0 ] . string ] [ 'ignorecache' ] = OOOOOoo0 ( 'ignorecache' ) [ 0 ] . string
   except :
    oOOO00o ( "Regex: -- no ignorecache" )
    if 74 - 74: I1i1iI1i
    if 61 - 61: I1i1iI1i - oOOO0OOooOoO0Oo * o0OO0 % II * o0O + o00ooo0
    if 71 - 71: IiiIIiiI11 / IiiIIiiI11 * II1Iiii1111i * II1Iiii1111i / o0OO0
    if 35 - 35: oO * Oo0oO0ooo * Oo0ooO0oo0oO % I1i1iI1i . o00
    if 58 - 58: IiiIIiiI11 + o0OO0 * IiiIII111ii * i11iIiiIii - o0O
  iiI = urllib . quote ( repr ( iiI ) )
  return iiI
  if 68 - 68: OoOO % o0OO0
 except :
  iiI = None
  oOOO00o ( 'regex Error: ' + i1I1iI . encode ( 'utf-8' , 'ignore' ) )
  if 26 - 26: o0OO0 % i11iIiiIii % o0O % IiiIIiiI11 * IiiIIiiI11 * O0OOo
def IiI1I11iIii ( url ) :
 try :
  for OOOOOoo0 in range ( 1 , 51 ) :
   IIi = O000O0OO00oo ( url )
   if "EXT-X-STREAM-INF" in IIi : return url
   if not "EXTM3U" in IIi : return
   xbmc . sleep ( 2000 )
  return
 except :
  return
  if 69 - 69: Oo0oO0ooo / I1i1iI1i
  if 43 - 43: O0OOo . Oo0ooO0oo0oO / OoOO % OoOO
def iIIIII1iiiiII ( regexs , url , cookieJar = None , forCookieJarOnly = False , recursiveCall = False , cachedPages = { } , rawPost = False , cookie_jar_file = None ) :
 if not recursiveCall :
  regexs = eval ( urllib . unquote ( regexs ) )
  if 54 - 54: I1iII1iiII
  if 22 - 22: I1iII1iiII + oooOOOOO
 O0o0O0OO00o = re . compile ( '\$doregex\[([^\]]*)\]' ) . findall ( url )
 if 92 - 92: Oo0oO0ooo + oOOO0OOooOoO0Oo / I1i1iI1i % o00ooo0 % i1iIIi1 . OoOO
 O0Oo = True
 if 7 - 7: i1iIIi1 % o0O + IiiIIiiI11 - oooOOOOO * II1Iiii1111i
 if 94 - 94: o00 . iiiiIi11i / oooOOOOO . O0OOo - I1iII1iiII
 if 26 - 26: o00ooo0 - oO . Oo0oO0ooo
 if 65 - 65: O0OOo % iiiiIi11i % o0O * oooOOOOO
 for iIIIIIiI1I1 in O0o0O0OO00o :
  if iIIIIIiI1I1 in regexs :
   if 15 - 15: oooOOOOO * I1i1iI1i % O0OOo * o0O - i11iIiiIii
   Oo00OOOOoo0oo = regexs [ iIIIIIiI1I1 ]
   if 80 - 80: oOOO0OOooOoO0Oo * o00 * o0OO0 - iiiiIi11i . o00 % Oo0ooO0oo0oO
   II1iiIIIiIii = False
   if 23 - 23: IiiIII111ii + IiiIIiiI11 . o00 * Oo0ooO0oo0oO + O0OOo
   if 18 - 18: i1iIIi1 * Oo0oO0ooo . i1iIIi1 / iiiiIi11i
   if 'cookiejar' in Oo00OOOOoo0oo :
    if 8 - 8: Oo0oO0ooo
    II1iiIIIiIii = Oo00OOOOoo0oo [ 'cookiejar' ]
    if '$doregex' in II1iiIIIiIii :
     cookieJar = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'cookiejar' ] , cookieJar , True , True , cachedPages )
     II1iiIIIiIii = True
    else :
     II1iiIIIiIii = True
     if 4 - 4: O0OOo + O0OOo * II - o00
   if II1iiIIIiIii :
    if cookieJar == None :
     if 78 - 78: oooOOOOO / o0OO0 % o00
     cookie_jar_file = None
     if 'open[' in Oo00OOOOoo0oo [ 'cookiejar' ] :
      cookie_jar_file = Oo00OOOOoo0oo [ 'cookiejar' ] . split ( 'open[' ) [ 1 ] . split ( ']' ) [ 0 ]
      if 52 - 52: oO - IiiIII111ii * II1Iiii1111i
     cookieJar = Ii1I11I ( cookie_jar_file )
     if cookie_jar_file :
      iiIii1I ( cookieJar , cookie_jar_file )
      if 47 - 47: II . IiiIIiiI11 / Oo0oO0ooo
      if 83 - 83: Oo0oO0ooo / oO / oO + Oo0oO0ooo * oOOO0OOooOoO0Oo + Oo0oO0ooo
      if 36 - 36: o00 + Oo0oO0ooo - OoOO . II1Iiii1111i . OoOO / I1i1iI1i
    elif 'save[' in Oo00OOOOoo0oo [ 'cookiejar' ] :
     cookie_jar_file = Oo00OOOOoo0oo [ 'cookiejar' ] . split ( 'save[' ) [ 1 ] . split ( ']' ) [ 0 ]
     o00Oi1i = os . path . join ( oo , cookie_jar_file )
     print 'complete_path' , o00Oi1i
     iiIii1I ( cookieJar , cookie_jar_file )
     if 5 - 5: II1Iiii1111i . O0OOo . o0OO0 . OoOO
     if 96 - 96: i11iIiiIii - oO % iiiiIi11i / o00ooo0
   if Oo00OOOOoo0oo [ 'page' ] and '$doregex' in Oo00OOOOoo0oo [ 'page' ] :
    Oo00OOOOoo0oo [ 'page' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'page' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 100 - 100: IiiIII111ii / oooOOOOO - OoOO % o0OO0 - Oo0ooO0oo0oO % o00
   if 'setcookie' in Oo00OOOOoo0oo and Oo00OOOOoo0oo [ 'setcookie' ] and '$doregex' in Oo00OOOOoo0oo [ 'setcookie' ] :
    Oo00OOOOoo0oo [ 'setcookie' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'setcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if 'appendcookie' in Oo00OOOOoo0oo and Oo00OOOOoo0oo [ 'appendcookie' ] and '$doregex' in Oo00OOOOoo0oo [ 'appendcookie' ] :
    Oo00OOOOoo0oo [ 'appendcookie' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'appendcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 60 - 60: o0O + I1iII1iiII
    if 86 - 86: o0O + o00 . i11iIiiIii - oooOOOOO
   if 'post' in Oo00OOOOoo0oo and '$doregex' in Oo00OOOOoo0oo [ 'post' ] :
    Oo00OOOOoo0oo [ 'post' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'post' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    print 'post is now' , Oo00OOOOoo0oo [ 'post' ]
    if 51 - 51: o00
   if 'rawpost' in Oo00OOOOoo0oo and '$doregex' in Oo00OOOOoo0oo [ 'rawpost' ] :
    Oo00OOOOoo0oo [ 'rawpost' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'rawpost' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages , rawPost = True )
    if 14 - 14: i1iIIi1 % II1Iiii1111i % I1i1iI1i - i11iIiiIii
    if 53 - 53: oooOOOOO % I1i1iI1i
   if 'rawpost' in Oo00OOOOoo0oo and '$epoctime$' in Oo00OOOOoo0oo [ 'rawpost' ] :
    Oo00OOOOoo0oo [ 'rawpost' ] = Oo00OOOOoo0oo [ 'rawpost' ] . replace ( '$epoctime$' , O0ooOo0o0Oo ( ) )
    if 71 - 71: o0O - oO . Oo0ooO0oo0oO % OoOO + oO
   if 'rawpost' in Oo00OOOOoo0oo and '$epoctime2$' in Oo00OOOOoo0oo [ 'rawpost' ] :
    Oo00OOOOoo0oo [ 'rawpost' ] = Oo00OOOOoo0oo [ 'rawpost' ] . replace ( '$epoctime2$' , IIi11I1 ( ) )
    if 49 - 49: o0OO0 - Oo0ooO0oo0oO / IiiIIiiI11
    if 74 - 74: IiiIIiiI11 - oO + I1iII1iiII . Oo0ooO0oo0oO + oO - IiiIIiiI11
   o00oOO0 = ''
   if Oo00OOOOoo0oo [ 'page' ] and Oo00OOOOoo0oo [ 'page' ] in cachedPages and not 'ignorecache' in Oo00OOOOoo0oo and forCookieJarOnly == False :
    o00oOO0 = cachedPages [ Oo00OOOOoo0oo [ 'page' ] ]
   else :
    if Oo00OOOOoo0oo [ 'page' ] and not Oo00OOOOoo0oo [ 'page' ] == '' and Oo00OOOOoo0oo [ 'page' ] . startswith ( 'http' ) :
     if '$epoctime$' in Oo00OOOOoo0oo [ 'page' ] :
      Oo00OOOOoo0oo [ 'page' ] = Oo00OOOOoo0oo [ 'page' ] . replace ( '$epoctime$' , O0ooOo0o0Oo ( ) )
     if '$epoctime2$' in Oo00OOOOoo0oo [ 'page' ] :
      Oo00OOOOoo0oo [ 'page' ] = Oo00OOOOoo0oo [ 'page' ] . replace ( '$epoctime2$' , IIi11I1 ( ) )
      if 17 - 17: iiiiIi11i . oOOO0OOooOoO0Oo . iiiiIi11i + iiiiIi11i / I1i1iI1i . II
      if 62 - 62: O0OOo % IiiIII111ii * o00ooo0 - I1iII1iiII
     OoOOo = Oo00OOOOoo0oo [ 'page' ] . split ( '|' )
     iii1 = OoOOo [ 0 ]
     oOO0oo = None
     if len ( OoOOo ) > 1 :
      oOO0oo = OoOOo [ 1 ]
     Ii1I = urllib2 . Request ( iii1 )
     Ii1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
     if 'refer' in Oo00OOOOoo0oo :
      Ii1I . add_header ( 'Referer' , Oo00OOOOoo0oo [ 'refer' ] )
     if 'agent' in Oo00OOOOoo0oo :
      Ii1I . add_header ( 'User-agent' , Oo00OOOOoo0oo [ 'agent' ] )
     if 'x-req' in Oo00OOOOoo0oo :
      Ii1I . add_header ( 'X-Requested-With' , Oo00OOOOoo0oo [ 'x-req' ] )
     if 'x-forward' in Oo00OOOOoo0oo :
      Ii1I . add_header ( 'X-Forwarded-For' , Oo00OOOOoo0oo [ 'x-forward' ] )
     if 'setcookie' in Oo00OOOOoo0oo :
      print 'adding cookie' , Oo00OOOOoo0oo [ 'setcookie' ]
      Ii1I . add_header ( 'Cookie' , Oo00OOOOoo0oo [ 'setcookie' ] )
     if 'appendcookie' in Oo00OOOOoo0oo :
      print 'appending cookie to cookiejar' , Oo00OOOOoo0oo [ 'appendcookie' ]
      II1iIi1IiIii = Oo00OOOOoo0oo [ 'appendcookie' ]
      II1iIi1IiIii = II1iIi1IiIii . split ( ';' )
      for I111I11I111 in II1iIi1IiIii :
       iiiiI11ii , O0i1i1II1i11 = I111I11I111 . split ( '=' )
       o00o , iiiiI11ii = iiiiI11ii . split ( ':' )
       iii11II1I = cookielib . Cookie ( version = 0 , name = iiiiI11ii , value = O0i1i1II1i11 , port = None , port_specified = False , domain = o00o , domain_specified = False , domain_initial_dot = False , path = '/' , path_specified = True , secure = False , expires = None , discard = True , comment = None , comment_url = None , rest = { 'HttpOnly' : None } , rfc2109 = False )
       cookieJar . set_cookie ( iii11II1I )
       if 5 - 5: o00 - i1iIIi1 * i1iIIi1
       if 50 - 50: o0OO0 * O0OOo / oooOOOOO . Oo0oO0ooo + I1i1iI1i - oO
       if 18 - 18: o00 % i11iIiiIii % O0OOo / II1Iiii1111i / Oo0oO0ooo / I1iII1iiII
       if 48 - 48: o00 + IiiIIiiI11 / i1iIIi1 + o0OO0
     if 'origin' in Oo00OOOOoo0oo :
      Ii1I . add_header ( 'Origin' , Oo00OOOOoo0oo [ 'origin' ] )
     if oOO0oo :
      oOO0oo = oOO0oo . split ( '&' )
      for I111I11I111 in oOO0oo :
       iiiiI11ii , O0i1i1II1i11 = I111I11I111 . split ( '=' )
       Ii1I . add_header ( iiiiI11ii , O0i1i1II1i11 )
       if 18 - 18: O0OOo
       if 23 - 23: o0OO0
     if not cookieJar == None :
      if 24 - 24: o0O + o0O * IiiIII111ii
      i1I11iIII1i1I = urllib2 . HTTPCookieProcessor ( cookieJar )
      oOO0ooIiIIi1I1I11Ii = urllib2 . build_opener ( i1I11iIII1i1I , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      oOO0ooIiIIi1I1I11Ii = urllib2 . install_opener ( oOO0ooIiIIi1I1I11Ii )
      if 'noredirect' in Oo00OOOOoo0oo :
       o0OO = urllib2 . build_opener ( o0oOoO00o )
       oOO0ooIiIIi1I1I11Ii = urllib2 . install_opener ( o0OO )
       if 58 - 58: OoOO . Oo0ooO0oo0oO / o0OO0 / o0OO0 - i1iIIi1 + I1i1iI1i
     if 'connection' in Oo00OOOOoo0oo :
      print '..........................connection//////.' , Oo00OOOOoo0oo [ 'connection' ]
      from keepalive import HTTPHandler
      Ooo0O0 = HTTPHandler ( )
      oOO0ooIiIIi1I1I11Ii = urllib2 . build_opener ( Ooo0O0 )
      urllib2 . install_opener ( oOO0ooIiIIi1I1I11Ii )
      if 71 - 71: OoOO
      if 11 - 11: i1iIIi1
     o0oooO = None
     if 89 - 89: o0OO0 / II1Iiii1111i
     if 'post' in Oo00OOOOoo0oo :
      IIo0OoO00 = Oo00OOOOoo0oo [ 'post' ]
      if '$LiveStreamRecaptcha' in IIo0OoO00 :
       ( IIIIIiII1 , iii11 ) = i1oO ( Oo00OOOOoo0oo [ 'page' ] )
       if IIIIIiII1 :
        IIo0OoO00 += 'recaptcha_challenge_field:' + IIIIIiII1 + ',recaptcha_response_field:' + iii11
      iIIi1IIi = IIo0OoO00 . split ( ',' ) ;
      o0oooO = { }
      for i111i11I1ii in iIIi1IIi :
       iiiiI11ii = i111i11I1ii . split ( ':' ) [ 0 ] ;
       O0i1i1II1i11 = i111i11I1ii . split ( ':' ) [ 1 ] ;
       o0oooO [ iiiiI11ii ] = O0i1i1II1i11
      o0oooO = urllib . urlencode ( o0oooO )
      if 64 - 64: II1Iiii1111i / i11iIiiIii / Oo0oO0ooo . OoOO
     if 'rawpost' in Oo00OOOOoo0oo :
      o0oooO = Oo00OOOOoo0oo [ 'rawpost' ]
      if '$LiveStreamRecaptcha' in o0oooO :
       ( IIIIIiII1 , iii11 ) = i1oO ( Oo00OOOOoo0oo [ 'page' ] )
       if IIIIIiII1 :
        o0oooO += '&recaptcha_challenge_field=' + IIIIIiII1 + '&recaptcha_response_field=' + iii11
        if 11 - 11: IiiIIiiI11 % I1iII1iiII
        if 16 - 16: Oo0ooO0oo0oO + II % o00
        if 80 - 80: II * iiiiIi11i
        if 78 - 78: o00
     if o0oooO :
      Oo0o0 = urllib2 . urlopen ( Ii1I , o0oooO )
     else :
      Oo0o0 = urllib2 . urlopen ( Ii1I )
      if 20 - 20: IiiIII111ii % oooOOOOO . oooOOOOO / IiiIIiiI11 + o00 . oooOOOOO
     o00oOO0 = Oo0o0 . read ( )
     o00oOO0 = O0ooOo0 ( o00oOO0 )
     if 53 - 53: OoOO - i1iIIi1
     if 'includeheaders' in Oo00OOOOoo0oo :
      o00oOO0 += str ( Oo0o0 . headers . get ( 'Set-Cookie' ) )
      if 87 - 87: II1Iiii1111i . Oo0ooO0oo0oO
     Oo0o0 . close ( )
     cachedPages [ Oo00OOOOoo0oo [ 'page' ] ] = o00oOO0
     if 17 - 17: oooOOOOO . i11iIiiIii
     if 5 - 5: O0OOo + iiiiIi11i + iiiiIi11i . oOOO0OOooOoO0Oo - II
     if 63 - 63: II1Iiii1111i
     if forCookieJarOnly :
      return cookieJar
    elif Oo00OOOOoo0oo [ 'page' ] and not Oo00OOOOoo0oo [ 'page' ] . startswith ( 'http' ) :
     if Oo00OOOOoo0oo [ 'page' ] . startswith ( '$pyFunction:' ) :
      Oo0OOo0Oo0OOo0 = i1i11I ( Oo00OOOOoo0oo [ 'page' ] . split ( '$pyFunction:' ) [ 1 ] , '' , cookieJar )
      if forCookieJarOnly :
       return cookieJar
      o00oOO0 = Oo0OOo0Oo0OOo0
     else :
      o00oOO0 = Oo00OOOOoo0oo [ 'page' ]
   if '$pyFunction:playmedia(' in Oo00OOOOoo0oo [ 'expre' ] or 'ActivateWindow' in Oo00OOOOoo0oo [ 'expre' ] or any ( x in url for x in i1i1II ) :
    O0Oo = False
   if '$doregex' in Oo00OOOOoo0oo [ 'expre' ] :
    Oo00OOOOoo0oo [ 'expre' ] = iIIIII1iiiiII ( regexs , Oo00OOOOoo0oo [ 'expre' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 7 - 7: o0OO0
    if 27 - 27: II1Iiii1111i . OoOO + i11iIiiIii
   if not Oo00OOOOoo0oo [ 'expre' ] == '' :
    print 'doing it ' , Oo00OOOOoo0oo [ 'expre' ]
    if '$LiveStreamCaptcha' in Oo00OOOOoo0oo [ 'expre' ] :
     Oo0OOo0Oo0OOo0 = O0OOIIIiIiI ( Oo00OOOOoo0oo , o00oOO0 , cookieJar )
     if 7 - 7: i1iIIi1 . o00 / O0OOo . oO * IiiIIiiI11 - o0OO0
     url = url . replace ( "$doregex[" + iIIIIIiI1I1 + "]" , Oo0OOo0Oo0OOo0 )
    elif Oo00OOOOoo0oo [ 'expre' ] . startswith ( '$pyFunction:' ) :
     if 37 - 37: oOOO0OOooOoO0Oo . o00 / iiiiIi11i * IiiIII111ii
     Oo0OOo0Oo0OOo0 = i1i11I ( Oo00OOOOoo0oo [ 'expre' ] . split ( '$pyFunction:' ) [ 1 ] , o00oOO0 , cookieJar )
     if 'ActivateWindow' in Oo00OOOOoo0oo [ 'expre' ] : return
     print 'still hre'
     print 'url k val' , url , iIIIIIiI1I1 , Oo0OOo0Oo0OOo0
     if 7 - 7: o00ooo0 * IiiIIiiI11 + o0OO0 % i11iIiiIii
     url = url . replace ( "$doregex[" + iIIIIIiI1I1 + "]" , Oo0OOo0Oo0OOo0 )
    else :
     if not o00oOO0 == '' :
      i1i1IiIiIi1Ii = re . compile ( Oo00OOOOoo0oo [ 'expre' ] ) . search ( o00oOO0 )
      Oo0OOo0Oo0OOo0 = ''
      try :
       Oo0OOo0Oo0OOo0 = i1i1IiIiIi1Ii . group ( 1 ) . strip ( )
      except : traceback . print_exc ( )
     else :
      Oo0OOo0Oo0OOo0 = Oo00OOOOoo0oo [ 'expre' ]
     if rawPost :
      print 'rawpost'
      Oo0OOo0Oo0OOo0 = urllib . quote_plus ( Oo0OOo0Oo0OOo0 )
     if 'htmlunescape' in Oo00OOOOoo0oo :
      if 64 - 64: oO + OoOO * OoOO
      import HTMLParser
      Oo0OOo0Oo0OOo0 = HTMLParser . HTMLParser ( ) . unescape ( Oo0OOo0Oo0OOo0 )
     url = url . replace ( "$doregex[" + iIIIIIiI1I1 + "]" , Oo0OOo0Oo0OOo0 )
     if 41 - 41: II . I1i1iI1i + Oo0ooO0oo0oO
   else :
    url = url . replace ( "$doregex[" + iIIIIIiI1I1 + "]" , '' )
 if '$epoctime$' in url :
  url = url . replace ( '$epoctime$' , O0ooOo0o0Oo ( ) )
 if '$epoctime2$' in url :
  url = url . replace ( '$epoctime2$' , IIi11I1 ( ) )
  if 100 - 100: oooOOOOO + o00ooo0
 if '$GUID$' in url :
  import uuid
  url = url . replace ( '$GUID$' , str ( uuid . uuid1 ( ) ) . upper ( ) )
 if '$get_cookies$' in url :
  url = url . replace ( '$get_cookies$' , Oo00o0OO ( cookieJar ) )
  if 73 - 73: Oo0oO0ooo - Oo0ooO0oo0oO * I1iII1iiII / i11iIiiIii * oO % o0OO0
 if recursiveCall : return url
 print 'final url' , url
 if url == "" :
  return
 else :
  return url , O0Oo
  if 56 - 56: OoOO * I1i1iI1i . I1i1iI1i . O0OOo
  if 24 - 24: I1i1iI1i . IiiIIiiI11 * oooOOOOO % IiiIII111ii / oO
  if 58 - 58: Oo0ooO0oo0oO - O0OOo % iiiiIi11i . Oo0ooO0oo0oO % o00ooo0 % i1iIIi1
def oOo0OooOo ( t ) :
 import hashlib
 I111I11I111 = hashlib . md5 ( )
 I111I11I111 . update ( t )
 return I111I11I111 . hexdigest ( )
 if 51 - 51: IiiIIiiI11 . I1i1iI1i
def IiiIiiIi ( encrypted ) :
 i1iiIIIi = ""
 for Oo0OOo0Oo0OOo0 in encrypted . split ( ':' ) :
  i1iiIIIi += chr ( int ( Oo0OOo0Oo0OOo0 . replace ( "0m0" , "" ) ) / 84 / 5 )
 return i1iiIIIi
 if 62 - 62: iiiiIi11i / Oo0ooO0oo0oO % iiiiIi11i * o00ooo0 % Oo0ooO0oo0oO
def IiOOoo0oO00oo00 ( media_url ) :
 try :
  import CustomPlayer
  O0ii = CustomPlayer . MyXBMCPlayer ( )
  ooO0o0oO = xbmcgui . ListItem ( label = str ( i1I1iI ) , iconImage = "DefaultVideo.png" , thumbnailImage = xbmc . getInfoImage ( "ListItem.Thumb" ) , path = media_url )
  O0ii . play ( media_url , ooO0o0oO )
  xbmc . sleep ( 1000 )
  while O0ii . is_active :
   xbmc . sleep ( 200 )
 except :
  traceback . print_exc ( )
 return ''
 if 67 - 67: OoOO
 if 29 - 29: iiiiIi11i - i11iIiiIii - o0OO0 + oO * i1iIIi1
def IiI1ii1Ii ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  oooOOOoOOOo0O = page_value
  page_value = O000O0OO00oo ( page_value , headers = referer )
  if 82 - 82: i1iIIi1 * i11iIiiIii % o0OO0 - OoOO
 OO0Ooo0 = "(eval\(function\(p,a,c,k,e,(?:r|d).*)"
 if 91 - 91: I1iII1iiII - o0O
 Oo0Oo00o00oO = re . compile ( OO0Ooo0 ) . findall ( page_value )
 O000Oo0o = ""
 if Oo0Oo00o00oO and len ( Oo0Oo00o00oO ) > 0 :
  for O0i1i1II1i11 in Oo0Oo00o00oO :
   o0000 = i111i1i ( O0i1i1II1i11 )
   IiIii1I1I = iiIII1i ( o0000 , '\'(.*?)\'' )
   if 'unescape' in o0000 :
    o0000 = urllib . unquote ( IiIii1I1I )
   O000Oo0o += o0000 + '\n'
  print 'final value is ' , O000Oo0o
  if 51 - 51: I1i1iI1i % o00 * OoOO . i11iIiiIii
  oooOOOoOOOo0O = iiIII1i ( O000Oo0o , 'src="(.*?)"' )
  if 77 - 77: o0OO0
  page_value = O000O0OO00oo ( oooOOOoOOOo0O , headers = referer )
  if 42 - 42: oooOOOOO * oOOO0OOooOoO0Oo . i1iIIi1 * Oo0ooO0oo0oO + o00
  if 25 - 25: IiiIIiiI11 . Oo0ooO0oo0oO + II1Iiii1111i
  if 75 - 75: i1iIIi1 - Oo0oO0ooo % IiiIII111ii + i11iIiiIii
 O0OOOo = iiIII1i ( page_value , 'streamer\'.*?\'(.*?)\'\)' )
 i1III = iiIII1i ( page_value , 'file\',\s\'(.*?)\'' )
 if 6 - 6: IiiIII111ii . IiiIIiiI11 + oooOOOOO . oOOO0OOooOoO0Oo
 if 70 - 70: o00ooo0
 return O0OOOo + ' playpath=' + i1III + ' pageUrl=' + oooOOOoOOOo0O
 if 46 - 46: IiiIIiiI11 - I1iII1iiII
def i111iiIIII ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  page_value = O000O0OO00oo ( page_value , headers = referer )
 OO0Ooo0 = "var a = (.*?);\s*var b = (.*?);\s*var c = (.*?);\s*var d = (.*?);\s*var f = (.*?);\s*var v_part = '(.*?)';"
 Oo0Oo00o00oO = re . compile ( OO0Ooo0 ) . findall ( page_value ) [ 0 ]
 if 80 - 80: I1i1iI1i * oooOOOOO + O0OOo * oO
 O0o , iIIIiiI1i1 , IIiI1 , I1Ii , ooooOoO0O , O0i1i1II1i11 = ( Oo0Oo00o00oO )
 ooooOoO0O = int ( ooooOoO0O )
 O0o = int ( O0o ) / ooooOoO0O
 iIIIiiI1i1 = int ( iIIIiiI1i1 ) / ooooOoO0O
 IIiI1 = int ( IIiI1 ) / ooooOoO0O
 I1Ii = int ( I1Ii ) / ooooOoO0O
 if 1 - 1: O0OOo / o00ooo0 + II1Iiii1111i . Oo0oO0ooo / O0OOo - IiiIII111ii
 ii111i1iI = 'rtmp://' + str ( O0o ) + '.' + str ( iIIIiiI1i1 ) + '.' + str ( IIiI1 ) + '.' + str ( I1Ii ) + O0i1i1II1i11 ;
 return ii111i1iI
 if 18 - 18: oO - oooOOOOO - o00 / oOOO0OOooOoO0Oo - iiiiIi11i
def iiIIii ( url , useragent = None ) :
 str = '#EXTM3U'
 str += '\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=361816'
 str += '\n' + url + '&bytes=0-200000'
 iIii1 = os . path . join ( oo , 'testfile.m3u' )
 str += '\n'
 oO0Oo0O0 ( iIii1 , str )
 if 49 - 49: II * II1Iiii1111i / Oo0oO0ooo / I1i1iI1i * o0O
 return iIii1
 if 57 - 57: o00 - II1Iiii1111i / II % i11iIiiIii
def oO0Oo0O0 ( file_name , page_data , append = False ) :
 if append :
  ooooOoO0O = open ( file_name , 'a' )
  ooooOoO0O . write ( page_data )
  ooooOoO0O . close ( )
 else :
  ooooOoO0O = open ( file_name , 'wb' )
  ooooOoO0O . write ( page_data )
  ooooOoO0O . close ( )
  return ''
  if 3 - 3: IiiIII111ii . II % Oo0ooO0oo0oO + O0OOo
def oo0o ( file_name ) :
 ooooOoO0O = open ( file_name , 'rb' )
 I1Ii = ooooOoO0O . read ( )
 ooooOoO0O . close ( )
 return I1Ii
 if 51 - 51: oO . Oo0ooO0oo0oO
def Oo ( page_data ) :
 import re , base64 , urllib ;
 iI1ii1Ii = page_data
 while 'geh(' in iI1ii1Ii :
  if iI1ii1Ii . startswith ( 'lol(' ) : iI1ii1Ii = iI1ii1Ii [ 5 : - 1 ]
  if 34 - 34: oOOO0OOooOoO0Oo % II1Iiii1111i % o00
  iI1ii1Ii = re . compile ( '"(.*?)"' ) . findall ( iI1ii1Ii ) [ 0 ] ;
  iI1ii1Ii = base64 . b64decode ( iI1ii1Ii ) ;
  iI1ii1Ii = urllib . unquote ( iI1ii1Ii ) ;
 print iI1ii1Ii
 return iI1ii1Ii
 if 63 - 63: Oo0ooO0oo0oO - o00ooo0 % IiiIII111ii % IiiIIiiI11 / Oo0oO0ooo / I1iII1iiII
def OO0oo0O0OOO0 ( page_data ) :
 print 'get_dag_url2' , page_data
 OoOOoIii1 = O000O0OO00oo ( page_data ) ;
 OoOOo00 = '(http.*)'
 import uuid
 O00O0O = str ( uuid . uuid1 ( ) ) . upper ( )
 O0OOoOOo0o = re . compile ( OoOOo00 ) . findall ( OoOOoIii1 )
 iIiii = [ ( 'X-Playback-Session-Id' , O00O0O ) ]
 for IiIii1ii in O0OOoOOo0o :
  try :
   IIiI1i = O000O0OO00oo ( IiIii1ii , headers = iIiii ) ;
   if 6 - 6: O0OOo / IiiIII111ii - oO
  except : pass
  if 62 - 62: IiiIIiiI11 % oO
 return page_data + '|&X-Playback-Session-Id=' + O00O0O
 if 54 - 54: o00 % IiiIII111ii . o00 * oO + o00 % I1iII1iiII
 if 23 - 23: oOOO0OOooOoO0Oo - oO + oooOOOOO - o00 * o00 . I1i1iI1i
def iIii11iI1II ( page_data ) :
 print 'get_dag_url' , page_data
 if page_data . startswith ( 'http://dag.total-stream.net' ) :
  iIiii = [ ( 'User-Agent' , 'Verismo-BlackUI_(2.4.7.5.8.0.34)' ) ]
  page_data = O000O0OO00oo ( page_data , headers = iIiii ) ;
  if 42 - 42: II - Oo0ooO0oo0oO + O0OOo % oooOOOOO
 if '127.0.0.1' in page_data :
  return IiIi1III ( page_data )
 elif iiIII1i ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  Ii1ii11IIIi = iiIII1i ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iiIII1i ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iiIII1i ( page_data , '\\?y=([^&]+)&' )
 else :
  Ii1ii11IIIi = iiIII1i ( page_data , 'href="([^"]+)"[^"]+$' )
  if len ( Ii1ii11IIIi ) == 0 :
   Ii1ii11IIIi = page_data
 Ii1ii11IIIi = Ii1ii11IIIi . replace ( ' ' , '%20' )
 return Ii1ii11IIIi
 if 82 - 82: II1Iiii1111i * o0O . Oo0oO0ooo . O0OOo + oO / Oo0ooO0oo0oO
def iiIII1i ( data , re_patten ) :
 IIIii1II1II = ''
 Oo00OOOOoo0oo = re . search ( re_patten , data )
 if Oo00OOOOoo0oo != None :
  IIIii1II1II = Oo00OOOOoo0oo . group ( 1 )
 else :
  IIIii1II1II = ''
 return IIIii1II1II
 if 58 - 58: oOOO0OOooOoO0Oo / II + iiiiIi11i + II . o0O + o0OO0
def IiIi1III ( page_data ) :
 Ii1ii11IIIi = ''
 if '127.0.0.1' in page_data :
  Ii1ii11IIIi = iiIII1i ( page_data , '&ver_t=([^&]+)&' ) + ' live=true timeout=15 playpath=' + iiIII1i ( page_data , '\\?y=([a-zA-Z0-9-_\\.@]+)' )
  if 37 - 37: IiiIIiiI11 . I1i1iI1i % i1iIIi1 * I1iII1iiII
 if iiIII1i ( page_data , 'token=([^&]+)&' ) != '' :
  Ii1ii11IIIi = Ii1ii11IIIi + '?token=' + iiIII1i ( page_data , 'token=([^&]+)&' )
 elif iiIII1i ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  Ii1ii11IIIi = iiIII1i ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iiIII1i ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iiIII1i ( page_data , '\\?y=([^&]+)&' )
 else :
  Ii1ii11IIIi = iiIII1i ( page_data , 'HREF="([^"]+)"' )
  if 71 - 71: I1i1iI1i / Oo0oO0ooo + oO
 if 'dag1.asx' in Ii1ii11IIIi :
  return iIii11iI1II ( Ii1ii11IIIi )
  if 48 - 48: oOOO0OOooOoO0Oo + IiiIII111ii
 if 'devinlivefs.fplive.net' not in Ii1ii11IIIi :
  Ii1ii11IIIi = Ii1ii11IIIi . replace ( 'devinlive' , 'flive' )
 if 'permlivefs.fplive.net' not in Ii1ii11IIIi :
  Ii1ii11IIIi = Ii1ii11IIIi . replace ( 'permlive' , 'flive' )
 return Ii1ii11IIIi
 if 16 - 16: o0O % i11iIiiIii . o00 % II + II1Iiii1111i . o00ooo0
 if 46 - 46: o00ooo0 - Oo0oO0ooo / o00 - OoOO + II1Iiii1111i
def OOOO ( str_eval ) :
 I1iI1i11 = ""
 try :
  Oo0oO00 = "w,i,s,e=(" + str_eval + ')'
  exec ( Oo0oO00 )
  I1iI1i11 = IiiI1III1I1 ( w , i , s , e )
 except : traceback . print_exc ( file = sys . stdout )
 if 80 - 80: oOOO0OOooOoO0Oo . IiiIIiiI11
 return I1iI1i11
 if 73 - 73: o00 . iiiiIi11i / IiiIII111ii * II1Iiii1111i
def IiiI1III1I1 ( w , i , s , e ) :
 i1iii1ii = 0 ;
 II1I11Iii1 = 0 ;
 i1iIIi1II1iiI = 0 ;
 III1Ii1i1I1 = [ ] ;
 O0O00OooO = [ ] ;
 while True :
  if ( i1iii1ii < 5 ) :
   O0O00OooO . append ( w [ i1iii1ii ] )
  elif ( i1iii1ii < len ( w ) ) :
   III1Ii1i1I1 . append ( w [ i1iii1ii ] ) ;
  i1iii1ii += 1 ;
  if ( II1I11Iii1 < 5 ) :
   O0O00OooO . append ( i [ II1I11Iii1 ] )
  elif ( II1I11Iii1 < len ( i ) ) :
   III1Ii1i1I1 . append ( i [ II1I11Iii1 ] )
  II1I11Iii1 += 1 ;
  if ( i1iIIi1II1iiI < 5 ) :
   O0O00OooO . append ( s [ i1iIIi1II1iiI ] )
  elif ( i1iIIi1II1iiI < len ( s ) ) :
   III1Ii1i1I1 . append ( s [ i1iIIi1II1iiI ] ) ;
  i1iIIi1II1iiI += 1 ;
  if ( len ( w ) + len ( i ) + len ( s ) + len ( e ) == len ( III1Ii1i1I1 ) + len ( O0O00OooO ) + len ( e ) ) :
   break ;
   if 40 - 40: IiiIIiiI11 % OoOO - oO + Oo0oO0ooo / oO
 ooO = '' . join ( III1Ii1i1I1 )
 iii1OO0o0oO0O000o = '' . join ( O0O00OooO )
 II1I11Iii1 = 0 ;
 I1iI11iii = [ ] ;
 for i1iii1ii in range ( 0 , len ( III1Ii1i1I1 ) , 2 ) :
  if 78 - 78: iiiiIi11i / o0OO0 * o00ooo0
  IiIi1iI11 = - 1 ;
  if ( ord ( iii1OO0o0oO0O000o [ II1I11Iii1 ] ) % 2 ) :
   IiIi1iI11 = 1 ;
   if 11 - 11: O0OOo
  I1iI11iii . append ( chr ( int ( ooO [ i1iii1ii : i1iii1ii + 2 ] , 36 ) - IiIi1iI11 ) ) ;
  II1I11Iii1 += 1 ;
  if ( II1I11Iii1 >= len ( O0O00OooO ) ) :
   II1I11Iii1 = 0 ;
 ii111i1iI = '' . join ( I1iI11iii )
 if 'eval(function(w,i,s,e)' in ii111i1iI :
  print 'STILL GOing'
  ii111i1iI = re . compile ( 'eval\(function\(w,i,s,e\).*}\((.*?)\)' ) . findall ( ii111i1iI ) [ 0 ]
  return OOOO ( ii111i1iI )
 else :
  print 'FINISHED'
  return ii111i1iI
  if 26 - 26: o0O * oOOO0OOooOoO0Oo - oO
def i111i1i ( page_value , regex_for_text = '' , iterations = 1 , total_iteration = 1 ) :
 try :
  III1II111Ii1 = None
  if page_value . startswith ( "http" ) :
   page_value = O000O0OO00oo ( page_value )
  print 'page_value' , page_value
  if regex_for_text and len ( regex_for_text ) > 0 :
   page_value = re . compile ( regex_for_text ) . findall ( page_value ) [ 0 ]
   if 82 - 82: oOOO0OOooOoO0Oo - oO + o00ooo0
  page_value = OO0iIiiIi11IIi ( page_value , iterations , total_iteration )
 except : traceback . print_exc ( file = sys . stdout )
 print 'unpacked' , page_value
 if 'sav1live.tv' in page_value :
  page_value = page_value . replace ( 'sav1live.tv' , 'sawlive.tv' )
  print 'sav1 unpacked' , page_value
 return page_value
 if 64 - 64: OoOO . O0OOo % iiiiIi11i + Oo0ooO0oo0oO - Oo0oO0ooo
def OO0iIiiIi11IIi ( sJavascript , iteration = 1 , totaliterations = 2 ) :
 print 'iteration' , iteration
 if sJavascript . startswith ( 'var _0xcb8a=' ) :
  ooo0oo00O00oO = sJavascript . split ( 'var _0xcb8a=' )
  Oo0oO00 = "myarray=" + ooo0oo00O00oO [ 1 ] . split ( "eval(" ) [ 0 ]
  exec ( Oo0oO00 )
  oOO = 62
  ooooo0OoO0 = int ( ooo0oo00O00oO [ 1 ] . split ( ",62," ) [ 1 ] . split ( ',' ) [ 0 ] )
  ii1I111i1Ii = myarray [ 0 ]
  OOOooO0OO0o = myarray [ 3 ]
  with open ( 'temp file' + str ( iteration ) + '.js' , "wb" ) as I1iIiiiI1 :
   I1iIiiiI1 . write ( str ( OOOooO0OO0o ) )
   if 42 - 42: oO % II1Iiii1111i / o00ooo0 - II1Iiii1111i * i11iIiiIii
 else :
  if 19 - 19: II1Iiii1111i * Oo0ooO0oo0oO % i11iIiiIii
  ooo0oo00O00oO = sJavascript . split ( "rn p}('" )
  print ooo0oo00O00oO
  if 24 - 24: Oo0oO0ooo
  ii1I111i1Ii , oOO , ooooo0OoO0 , OOOooO0OO0o = ( '' , '0' , '0' , '' )
  if 10 - 10: Oo0oO0ooo % oooOOOOO / oO
  Oo0oO00 = "p1,a1,c1,k1=('" + ooo0oo00O00oO [ 1 ] . split ( ".spli" ) [ 0 ] + ')'
  exec ( Oo0oO00 )
 OOOooO0OO0o = OOOooO0OO0o . split ( '|' )
 ooo0oo00O00oO = ooo0oo00O00oO [ 1 ] . split ( "))'" )
 if 28 - 28: oO % II
 if 48 - 48: i11iIiiIii % II1Iiii1111i
 if 29 - 29: IiiIII111ii + i11iIiiIii % IiiIIiiI11
 if 93 - 93: o00 % o0O
 if 90 - 90: Oo0ooO0oo0oO - oO / oooOOOOO / iiiiIi11i / IiiIIiiI11
 if 87 - 87: o00 / i1iIIi1 + o0O
 if 93 - 93: o0O + II1Iiii1111i % II
 if 21 - 21: oO
 if 6 - 6: i1iIIi1
 if 46 - 46: i1iIIi1 + II1Iiii1111i
 if 79 - 79: OoOO - i1iIIi1 * i1iIIi1 . o00
 if 100 - 100: o0OO0 * IiiIIiiI11 % Oo0ooO0oo0oO / O0OOo
 if 90 - 90: O0OOo . II . o00 . oooOOOOO
 if 4 - 4: oooOOOOO + o00 % O0OOo / i11iIiiIii
 if 74 - 74: o0OO0 . iiiiIi11i - Oo0ooO0oo0oO + i1iIIi1 % i11iIiiIii % o00
 if 78 - 78: oooOOOOO + o00 + i1iIIi1 - i1iIIi1 . i11iIiiIii / o00ooo0
 if 27 - 27: oooOOOOO - iiiiIi11i % IiiIIiiI11 * oOOO0OOooOoO0Oo . i1iIIi1 % o0O
 if 37 - 37: OoOO + iiiiIi11i - I1iII1iiII % II
 if 24 - 24: o00
 if 94 - 94: I1iII1iiII * I1iII1iiII % o0OO0 + oO
 if 28 - 28: Oo0ooO0oo0oO
 if 49 - 49: IiiIIiiI11 . Oo0oO0ooo % II1Iiii1111i / oooOOOOO
 oo0oooooO0 = ''
 I1Ii = ''
 if 95 - 95: iiiiIi11i * o00 * i1iIIi1 . II / o0O
 if 28 - 28: i1iIIi1 + II1Iiii1111i - II / o0O - Oo0ooO0oo0oO
 Ii1i1 = str ( oOoO00 ( ii1I111i1Ii , oOO , ooooo0OoO0 , OOOooO0OO0o , oo0oooooO0 , I1Ii , iteration ) )
 if 45 - 45: oooOOOOO . OoOO
 if 27 - 27: oooOOOOO * I1i1iI1i . o00
 if 17 - 17: o0OO0 % IiiIII111ii * oO % I1iII1iiII . Oo0ooO0oo0oO . o0O
 if 27 - 27: i11iIiiIii - Oo0ooO0oo0oO
 if 35 - 35: OoOO - oOOO0OOooOoO0Oo / o00ooo0
 if iteration >= totaliterations :
  if 50 - 50: o00
  return Ii1i1
 else :
  if 33 - 33: IiiIIiiI11
  return OO0iIiiIi11IIi ( Ii1i1 , iteration + 1 )
  if 98 - 98: o00 % o0OO0
def oOoO00 ( p , a , c , k , e , d , iteration , v = 1 ) :
 if 95 - 95: o0O - oOOO0OOooOoO0Oo - oO + oOOO0OOooOoO0Oo % O0OOo . Oo0ooO0oo0oO
 if 41 - 41: iiiiIi11i + II1Iiii1111i . I1iII1iiII - o0OO0 * Oo0oO0ooo . o00ooo0
 if 68 - 68: Oo0oO0ooo
 while ( c >= 1 ) :
  c = c - 1
  if ( k [ c ] ) :
   i11Ii1IIi = str ( Ii1I11i11I1i ( c , a ) )
   if v == 1 :
    p = re . sub ( '\\b' + i11Ii1IIi + '\\b' , k [ c ] , p )
   else :
    p = oO00 ( p , i11Ii1IIi , k [ c ] )
    if 7 - 7: iiiiIi11i % oOOO0OOooOoO0Oo + O0OOo + oooOOOOO % OoOO . I1i1iI1i
    if 56 - 56: IiiIII111ii
    if 84 - 84: o00 - i11iIiiIii
    if 1 - 1: IiiIII111ii * o00
    if 66 - 66: o00 + I1iII1iiII % o0OO0 . iiiiIi11i * O0OOo % O0OOo
    if 87 - 87: oO + Oo0oO0ooo . IiiIII111ii - OoOO
 return p
 if 6 - 6: o0O * OoOO
 if 28 - 28: I1i1iI1i * Oo0oO0ooo / oOOO0OOooOoO0Oo
 if 52 - 52: iiiiIi11i / Oo0oO0ooo % IiiIII111ii * Oo0ooO0oo0oO % oO
def oO00 ( source_str , word_to_find , replace_with ) :
 o0oOOOO0 = None
 o0oOOOO0 = source_str . split ( word_to_find )
 if len ( o0oOOOO0 ) > 1 :
  ii1IOO0oOo00 = [ ]
  i11I1I = 0
  for oo0ooooo00o in o0oOOOO0 :
   if 78 - 78: o0O . Oo0oO0ooo % o0O . iiiiIi11i / oO
   ii1IOO0oOo00 . append ( oo0ooooo00o )
   Oo0OOo0Oo0OOo0 = word_to_find
   if 76 - 76: I1iII1iiII * OoOO * iiiiIi11i + oOOO0OOooOoO0Oo * oOOO0OOooOoO0Oo
   if 35 - 35: Oo0oO0ooo
   if i11I1I == len ( o0oOOOO0 ) - 1 :
    Oo0OOo0Oo0OOo0 = ''
   else :
    if len ( oo0ooooo00o ) == 0 :
     if ( len ( o0oOOOO0 [ i11I1I + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( o0oOOOO0 [ i11I1I + 1 ] ) > 0 and o0oOOOO0 [ i11I1I + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) :
      Oo0OOo0Oo0OOo0 = replace_with
      if 73 - 73: iiiiIi11i - O0OOo
    else :
     if ( o0oOOOO0 [ i11I1I ] [ - 1 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) and ( ( len ( o0oOOOO0 [ i11I1I + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( o0oOOOO0 [ i11I1I + 1 ] ) > 0 and o0oOOOO0 [ i11I1I + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) ) :
      Oo0OOo0Oo0OOo0 = replace_with
      if 2 - 2: o0OO0 / oOOO0OOooOoO0Oo
   ii1IOO0oOo00 . append ( Oo0OOo0Oo0OOo0 )
   i11I1I += 1
   if 54 - 54: I1iII1iiII . IiiIIiiI11 - O0OOo + II + I1i1iI1i / I1i1iI1i
  source_str = '' . join ( ii1IOO0oOo00 )
 return source_str
 if 22 - 22: II . o0O
def i1IiiiiIi1I ( num , radix ) :
 if 56 - 56: OoOO * iiiiIi11i
 IIi = ""
 if num == 0 : return '0'
 while num > 0 :
  IIi = "0123456789abcdefghijklmnopqrstuvwxyz" [ num % radix ] + IIi
  num /= radix
 return IIi
 if 85 - 85: OoOO % o00 * o0O
def Ii1I11i11I1i ( cc , a ) :
 i11Ii1IIi = "" if cc < a else Ii1I11i11I1i ( int ( cc / a ) , a )
 cc = ( cc % a )
 IiI = chr ( cc + 29 ) if cc > 35 else str ( i1IiiiiIi1I ( cc , 36 ) )
 return i11Ii1IIi + IiI
 if 60 - 60: oOOO0OOooOoO0Oo
 if 98 - 98: II
def Oo00o0OO ( cookieJar ) :
 try :
  Ii11i1Ii1IIII = ""
  for o00O0 , i1iiI in enumerate ( cookieJar ) :
   Ii11i1Ii1IIII += i1iiI . name + "=" + i1iiI . value + ";"
 except : pass
 if 63 - 63: iiiiIi11i
 return Ii11i1Ii1IIII
 if 6 - 6: oO
 if 98 - 98: OoOO % iiiiIi11i - iiiiIi11i
def iiIii1I ( cookieJar , COOKIEFILE ) :
 try :
  o00Oi1i = os . path . join ( oo , COOKIEFILE )
  cookieJar . save ( o00Oi1i , ignore_discard = True )
 except : pass
 if 76 - 76: I1iII1iiII % o00 - Oo0ooO0oo0oO / Oo0oO0ooo * II
def Ii1I11I ( COOKIEFILE ) :
 if 4 - 4: I1i1iI1i * I1i1iI1i / o00
 Ii1Ii1Ii1I1I = None
 if COOKIEFILE :
  try :
   o00Oi1i = os . path . join ( oo , COOKIEFILE )
   Ii1Ii1Ii1I1I = cookielib . LWPCookieJar ( )
   Ii1Ii1Ii1I1I . load ( o00Oi1i , ignore_discard = True )
  except :
   Ii1Ii1Ii1I1I = None
   if 48 - 48: I1i1iI1i - II + I1i1iI1i - Oo0ooO0oo0oO * i11iIiiIii . IiiIII111ii
 if not Ii1Ii1Ii1I1I :
  Ii1Ii1Ii1I1I = cookielib . LWPCookieJar ( )
  if 35 - 35: i1iIIi1 . iiiiIi11i + I1i1iI1i + oO + I1iII1iiII
 return Ii1Ii1Ii1I1I
 if 65 - 65: iiiiIi11i * Oo0ooO0oo0oO / Oo0ooO0oo0oO . o00
def i1i11I ( fun_call , page_data , Cookie_Jar ) :
 Oo0O0OOO0o0O = ''
 if oOOoO0 not in sys . path :
  sys . path . append ( oOOoO0 )
  if 51 - 51: II1Iiii1111i + o00ooo0 + IiiIII111ii + IiiIII111ii % Oo0oO0ooo
 print fun_call
 try :
  iIi1i1iIi1Ii1 = 'import ' + fun_call . split ( '.' ) [ 0 ]
  print iIi1i1iIi1Ii1 , sys . path
  exec ( iIi1i1iIi1Ii1 )
  print 'done'
 except :
  print 'error in import'
  traceback . print_exc ( file = sys . stdout )
 print 'ret_val=' + fun_call
 exec ( 'ret_val=' + fun_call )
 print Oo0O0OOO0o0O
 if 66 - 66: o00ooo0 % Oo0oO0ooo
 return str ( Oo0O0OOO0o0O )
 if 21 - 21: o00 - OoOO % i11iIiiIii
def i1oO ( url ) :
 Oo00O0OO = O000O0OO00oo ( url )
 oOOOoo0o = ""
 iiiI1IiIIii = ""
 IIIIiii = "<script.*?src=\"(.*?recap.*?)\""
 IIIii1II1II = re . findall ( IIIIiii , Oo00O0OO )
 Ii11Ii1iI = False
 OOOo00 = None
 iiiI1IiIIii = None
 if 15 - 15: IiiIIiiI11
 if IIIii1II1II and len ( IIIii1II1II ) > 0 :
  O00o0oo0oOO = IIIii1II1II [ 0 ]
  Ii11Ii1iI = True
  if 75 - 75: o0O + OoOO
  oOOO0 = 'challenge.*?\'(.*?)\''
  i111I11i1I = '\'(.*?)\''
  O00oOo0O0o00O = O000O0OO00oo ( O00o0oo0oOO )
  oOOOoo0o = re . findall ( oOOO0 , O00oOo0O0o00O ) [ 0 ]
  ooo0oo00O00Oo = 'http://www.google.com/recaptcha/api/reload?c=' ;
  OOO000000OOO0 = O00o0oo0oOO . split ( 'k=' ) [ 1 ]
  ooo0oo00O00Oo += oOOOoo0o + '&k=' + OOO000000OOO0 + '&captcha_k=1&type=image&lang=en-GB'
  ooOoOOoooO000 = O000O0OO00oo ( ooo0oo00O00Oo )
  OOOo00 = re . findall ( i111I11i1I , ooOoOOoooO000 ) [ 0 ]
  OoO0o000oOo = 'http://www.google.com/recaptcha/api/image?c=' + OOOo00
  if not OoO0o000oOo . startswith ( "http" ) :
   OoO0o000oOo = 'http://www.google.com/recaptcha/api/' + OoO0o000oOo
  import random
  iiiiI11ii = random . randrange ( 100 , 1000 , 5 )
  Oo00OO00o0oO = os . path . join ( oo , str ( iiiiI11ii ) + "captcha.img" )
  iI1 = open ( Oo00OO00o0oO , "wb" )
  iI1 . write ( O000O0OO00oo ( OoO0o000oOo ) )
  iI1 . close ( )
  I1I1i1i = OOo0O ( captcha = Oo00OO00o0oO )
  iiiI1IiIIii = I1I1i1i . get ( )
  os . remove ( Oo00OO00o0oO )
 return OOOo00 , iiiI1IiIIii
 if 100 - 100: o00ooo0 % o00ooo0
def O000O0OO00oo ( url , cookieJar = None , post = None , timeout = 20 , headers = None ) :
 if 15 - 15: II1Iiii1111i / oOOO0OOooOoO0Oo
 if 37 - 37: i11iIiiIii + Oo0ooO0oo0oO . oO % IiiIIiiI11 % IiiIIiiI11
 i1I11iIII1i1I = urllib2 . HTTPCookieProcessor ( cookieJar )
 oOO0ooIiIIi1I1I11Ii = urllib2 . build_opener ( i1I11iIII1i1I , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
 if 26 - 26: iiiiIi11i
 Ii1I = urllib2 . Request ( url )
 Ii1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36' )
 if headers :
  for I111I11I111 , i111I1iiIiII in headers :
   Ii1I . add_header ( I111I11I111 , i111I1iiIiII )
   if 97 - 97: o0OO0 - oOOO0OOooOoO0Oo - o0O * Oo0ooO0oo0oO
 Oo0o0 = oOO0ooIiIIi1I1I11Ii . open ( Ii1I , post , timeout = timeout )
 o00oOO0 = Oo0o0 . read ( )
 Oo0o0 . close ( )
 return o00oOO0 ;
 if 54 - 54: o0O
def i111i1I1ii1i ( str , reg = None ) :
 if reg :
  str = re . findall ( reg , str ) [ 0 ]
 O0O = urllib . unquote ( str [ 0 : len ( str ) - 1 ] ) ;
 ooo = '' ;
 for OOOOOoo0 in range ( len ( O0O ) ) :
  ooo += chr ( ord ( O0O [ OOOOOoo0 ] ) - O0O [ len ( O0O ) - 1 ] ) ;
 ooo = urllib . unquote ( ooo )
 print ooo
 return ooo
 if 27 - 27: II + i11iIiiIii * IiiIIiiI11 + o00 + IiiIII111ii
def O0ooOo0 ( str ) :
 o0o = re . findall ( 'unescape\(\'(.*?)\'' , str )
 print 'js' , o0o
 if ( not o0o == None ) and len ( o0o ) > 0 :
  for I1II1 in o0o :
   if 53 - 53: iiiiIi11i + oO % i11iIiiIii * oO
   str = str . replace ( I1II1 , urllib . unquote ( I1II1 ) )
 return str
 if 69 - 69: II - OoOO * iiiiIi11i
O0Oo0O0 = 0
def O0OOIIIiIiI ( m , html_page , cookieJar ) :
 global O0Oo0O0
 O0Oo0O0 += 1
 I1IiiIiii1 = m [ 'expre' ]
 oooOOOoOOOo0O = m [ 'page' ]
 i11i = re . compile ( '\$LiveStreamCaptcha\[([^\]]*)\]' ) . findall ( I1IiiIiii1 ) [ 0 ]
 if 86 - 86: oooOOOOO
 O00o0oo0oOO = re . compile ( i11i ) . findall ( html_page ) [ 0 ]
 print I1IiiIiii1 , i11i , O00o0oo0oOO
 if not O00o0oo0oOO . startswith ( "http" ) :
  IiII1i1iI = 'http://' + "" . join ( oooOOOoOOOo0O . split ( '/' ) [ 2 : 3 ] )
  if O00o0oo0oOO . startswith ( "/" ) :
   O00o0oo0oOO = IiII1i1iI + O00o0oo0oOO
  else :
   O00o0oo0oOO = IiII1i1iI + '/' + O00o0oo0oOO
   if 84 - 84: i1iIIi1 + O0OOo + oooOOOOO + IiiIII111ii
 Oo00OO00o0oO = os . path . join ( oo , str ( O0Oo0O0 ) + "captcha.jpg" )
 iI1 = open ( Oo00OO00o0oO , "wb" )
 print ' c capurl' , O00o0oo0oOO
 Ii1I = urllib2 . Request ( O00o0oo0oOO )
 Ii1I . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
 if 'refer' in m :
  Ii1I . add_header ( 'Referer' , m [ 'refer' ] )
 if 'agent' in m :
  Ii1I . add_header ( 'User-agent' , m [ 'agent' ] )
 if 'setcookie' in m :
  print 'adding cookie' , m [ 'setcookie' ]
  Ii1I . add_header ( 'Cookie' , m [ 'setcookie' ] )
  if 62 - 62: i11iIiiIii + o00 + I1iII1iiII
  if 69 - 69: o00
  if 63 - 63: o00ooo0 / o00 * o0O . oOOO0OOooOoO0Oo
  if 85 - 85: i11iIiiIii / i11iIiiIii . o00ooo0 . iiiiIi11i
 urllib2 . urlopen ( Ii1I )
 Oo0o0 = urllib2 . urlopen ( Ii1I )
 if 67 - 67: o0OO0 / Oo0oO0ooo . oO . OoOO
 iI1 . write ( Oo0o0 . read ( ) )
 Oo0o0 . close ( )
 iI1 . close ( )
 I1I1i1i = OOo0O ( captcha = Oo00OO00o0oO )
 iiiI1IiIIii = I1I1i1i . get ( )
 return iiiI1IiIIii
 if 19 - 19: i1iIIi1 . O0OOo / o00
class OOo0O ( xbmcgui . WindowDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  self . cptloc = kwargs . get ( 'captcha' )
  self . img = xbmcgui . ControlImage ( 335 , 30 , 624 , 60 , self . cptloc )
  self . addControl ( self . img )
  self . kbd = xbmc . Keyboard ( )
  if 68 - 68: II / OoOO * IiiIIiiI11 / II1Iiii1111i
 def get ( self ) :
  self . show ( )
  time . sleep ( 2 )
  self . kbd . doModal ( )
  if ( self . kbd . isConfirmed ( ) ) :
   ooooO000 = self . kbd . getText ( )
   self . close ( )
   return ooooO000
  self . close ( )
  return False
  if 61 - 61: II - oO + oO
def O0ooOo0o0Oo ( ) :
 import time
 return str ( int ( time . time ( ) * 1000 ) )
 if 40 - 40: i11iIiiIii . o0O
def IIi11I1 ( ) :
 import time
 return str ( int ( time . time ( ) ) )
 if 2 - 2: I1iII1iiII * II1Iiii1111i - II1Iiii1111i + OoOO % o00 / o00
def i11 ( ) :
 Ii ( )
 IiI1iiI11 = [ ]
 OOoOOOO00 = sys . argv [ 2 ]
 if len ( OOoOOOO00 ) >= 2 :
  IIii1III = sys . argv [ 2 ]
  ooooOoo0OO = IIii1III . replace ( '?' , '' )
  if ( IIii1III [ len ( IIii1III ) - 1 ] == '/' ) :
   IIii1III = IIii1III [ 0 : len ( IIii1III ) - 2 ]
  Oo0O0000Oo00o = ooooOoo0OO . split ( '&' )
  IiI1iiI11 = { }
  for OOOOOoo0 in range ( len ( Oo0O0000Oo00o ) ) :
   II1ii = { }
   II1ii = Oo0O0000Oo00o [ OOOOOoo0 ] . split ( '=' )
   if ( len ( II1ii ) ) == 2 :
    IiI1iiI11 [ II1ii [ 0 ] ] = II1ii [ 1 ]
 return IiI1iiI11
 if 89 - 89: IiiIII111ii . i11iIiiIii * iiiiIi11i
 if 44 - 44: I1iII1iiII . Oo0ooO0oo0oO / i11iIiiIii + i1iIIi1
def iI111II1ii ( ) :
 oo0O0o00o0O = json . loads ( open ( IIIII ) . read ( ) )
 IIIIiIiIi1 = len ( oo0O0o00o0O )
 for OOOOOoo0 in oo0O0o00o0O :
  i1I1iI = OOOOOoo0 [ 0 ]
  oOo0O = OOOOOoo0 [ 1 ]
  O0ooO00ooOO0o = OOOOOoo0 [ 2 ]
  try :
   O000 = OOOOOoo0 [ 3 ]
   if O000 == None :
    raise
  except :
   if i1IIi11111i . getSetting ( 'use_thumb' ) == "true" :
    O000 = O0ooO00ooOO0o
   else :
    O000 = o0OO00oO
  try : i11i1iIiii = OOOOOoo0 [ 5 ]
  except : i11i1iIiii = None
  try : iiI = OOOOOoo0 [ 6 ]
  except : iiI = None
  if 65 - 65: IiiIII111ii . o00ooo0 + oooOOOOO
  if OOOOOoo0 [ 4 ] == 0 :
   oO0Oo ( oOo0O , i1I1iI , O0ooO00ooOO0o , O000 , '' , '' , '' , 'fav' , i11i1iIiii , iiI , IIIIiIiIi1 )
  else :
   i1Iii1i1I ( i1I1iI , oOo0O , OOOOOoo0 [ 4 ] , O0ooO00ooOO0o , o0OO00oO , '' , '' , '' , '' , 'fav' )
   if 25 - 25: Oo0oO0ooo + I1i1iI1i . I1i1iI1i % OoOO - oooOOOOO
   if 43 - 43: o00ooo0 % o00ooo0
def IIiii11ii1i ( name , url , iconimage , fanart , mode , playlist = None , regexs = None ) :
 II1iI1IIi = [ ]
 if not os . path . exists ( IIIII + 'txt' ) :
  os . makedirs ( IIIII + 'txt' )
 if not os . path . exists ( I1 ) :
  os . makedirs ( I1 )
 try :
  if 41 - 41: Oo0ooO0oo0oO - oOOO0OOooOoO0Oo % o0OO0 . oOOO0OOooOoO0Oo - IiiIIiiI11
  name = name . encode ( 'utf-8' , 'ignore' )
 except :
  pass
 if os . path . exists ( IIIII ) == False :
  oOOO00o ( 'Making Favorites File' )
  II1iI1IIi . append ( ( name , url , iconimage , fanart , mode , playlist , regexs ) )
  O0o = open ( IIIII , "w" )
  O0o . write ( json . dumps ( II1iI1IIi ) )
  O0o . close ( )
 else :
  oOOO00o ( 'Appending Favorites' )
  O0o = open ( IIIII ) . read ( )
  III1ii1iII = json . loads ( O0o )
  III1ii1iII . append ( ( name , url , iconimage , fanart , mode ) )
  iIIIiiI1i1 = open ( IIIII , "w" )
  iIIIiiI1i1 . write ( json . dumps ( III1ii1iII ) )
  iIIIiiI1i1 . close ( )
  if 45 - 45: oooOOOOO - oO
  if 70 - 70: o00ooo0 % Oo0ooO0oo0oO / Oo0ooO0oo0oO . IiiIIiiI11 % II . o0OO0
def I1ii1Ii1 ( name ) :
 III1ii1iII = json . loads ( open ( IIIII ) . read ( ) )
 for o00O0 in range ( len ( III1ii1iII ) ) :
  if III1ii1iII [ o00O0 ] [ 0 ] == name :
   del III1ii1iII [ o00O0 ]
   iIIIiiI1i1 = open ( IIIII , "w" )
   iIIIiiI1i1 . write ( json . dumps ( III1ii1iII ) )
   iIIIiiI1i1 . close ( )
   break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 73 - 73: iiiiIi11i . II1Iiii1111i + i11iIiiIii + o0O - IiiIIiiI11 / o00
def I1i111iiIIIi ( url ) :
 if i1IIi11111i . getSetting ( 'Updatecommonresolvers' ) == 'true' :
  IiIii1ii = os . path . join ( IiII1I1i1i1ii , 'genesisresolvers.py' )
  if xbmcvfs . exists ( IiIii1ii ) :
   os . remove ( IiIii1ii )
   if 99 - 99: O0OOo * II1Iiii1111i * O0OOo - o0OO0 + oooOOOOO
  OOooO0Oo00 = 'https://raw.githubusercontent.com/lambda81/lambda-addons/master/plugin.video.genesis/commonresolvers.py'
  iIIIIIIIiIII = urllib . urlretrieve ( OOooO0Oo00 , IiIii1ii )
  i1IIi11111i . setSetting ( 'Updatecommonresolvers' , 'false' )
 try :
  import genesisresolvers
 except Exception :
  xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,Please enable Update Commonresolvers to Play in Settings. - ,10000)" )
  if 94 - 94: IiiIII111ii * o0O . IiiIIiiI11
 IiiI11I1IIiI = genesisresolvers . get ( url ) . result
 if url == IiiI11I1IIiI or IiiI11I1IIiI is None :
  if 5 - 5: I1i1iI1i
  xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,Is Finding Your Link - ,5000)" )
  import urlresolver
  o0oOo00 = urlresolver . HostedMediaFile ( url )
  if o0oOo00 :
   IiI1III = urlresolver . resolve ( url )
   IiiI11I1IIiI = IiI1III
 if IiiI11I1IIiI :
  if isinstance ( IiiI11I1IIiI , list ) :
   for iIIIIIiI1I1 in IiiI11I1IIiI :
    O0O0OOO = i1IIi11111i . getSetting ( 'quality' )
    if iIIIIIiI1I1 [ 'quality' ] == 'HD' :
     IiI1III = iIIIIIiI1I1 [ 'url' ]
     break
    elif iIIIIIiI1I1 [ 'quality' ] == 'SD' :
     IiI1III = iIIIIIiI1I1 [ 'url' ]
    elif iIIIIIiI1I1 [ 'quality' ] == '1080p' and i1IIi11111i . getSetting ( '1080pquality' ) == 'true' :
     IiI1III = iIIIIIiI1I1 [ 'url' ]
     break
  else :
   IiI1III = IiiI11I1IIiI
 return IiI1III
def I1IIi ( name , mu_playlist ) :
 import urlparse
 if i1IIi11111i . getSetting ( 'ask_playlist_items' ) == 'true' :
  I11I11I11IiIi = [ ]
  for OOOOOoo0 in mu_playlist :
   OOii1ii1i11I1I = urlparse . urlparse ( OOOOOoo0 ) . netloc
   if OOii1ii1i11I1I == '' :
    I11I11I11IiIi . append ( name )
   else :
    I11I11I11IiIi . append ( OOii1ii1i11I1I )
  O00 = xbmcgui . Dialog ( )
  o00O0 = O00 . select ( 'Choose a video source' , I11I11I11IiIi )
  if o00O0 >= 0 :
   if "&mode=19" in mu_playlist [ o00O0 ] :
    xbmc . Player ( ) . play ( I1i111iiIIIi ( mu_playlist [ o00O0 ] . replace ( '&mode=19' , '' ) ) )
   elif "$doregex" in mu_playlist [ o00O0 ] :
    if 41 - 41: i1iIIi1
    i1iiii = mu_playlist [ o00O0 ] . split ( '&regexs=' )
    if 17 - 17: o0OO0
    oOo0O , O0Oo = iIIIII1iiiiII ( i1iiii [ 1 ] , i1iiii [ 0 ] )
    xbmc . Player ( ) . play ( oOo0O )
   else :
    oOo0O = mu_playlist [ o00O0 ]
    xbmc . Player ( ) . play ( oOo0O )
 else :
  i11i1iIiii = xbmc . PlayList ( 1 )
  i11i1iIiii . clear ( )
  i1II1 = 0
  for OOOOOoo0 in mu_playlist :
   i1II1 += 1
   iiIiii = xbmcgui . ListItem ( '%s) %s' % ( str ( i1II1 ) , name ) )
   i11i1iIiii . add ( OOOOOoo0 , iiIiii )
   xbmc . executebuiltin ( 'playlist.playoffset(video,0)' )
   if 39 - 39: Oo0ooO0oo0oO + I1i1iI1i
   if 83 - 83: I1iII1iiII
def O0OooOO ( name , url ) :
 if i1IIi11111i . getSetting ( 'save_location' ) == "" :
  xbmc . executebuiltin ( "XBMC.Notification('Furious Streams','Choose a location to save files.',15000," + iI111I11I1I1 + ")" )
  i1IIi11111i . openSettings ( )
 IIii1III = { 'url' : url , 'download_path' : i1IIi11111i . getSetting ( 'save_location' ) }
 downloader . download ( name , IIii1III )
 O00 = xbmcgui . Dialog ( )
 ii111i1iI = O00 . yesno ( 'Furious Streams' , 'Do you want to add this file as a source?' )
 if ii111i1iI :
  Ooo ( os . path . join ( i1IIi11111i . getSetting ( 'save_location' ) , name ) )
  if 49 - 49: i1iIIi1 / II / oO
  if 25 - 25: Oo0ooO0oo0oO % iiiiIi11i + I1iII1iiII - II
def i1Iii1i1I ( name , url , mode , iconimage , fanart , description , genre , date , credits , showcontext = False ) :
 if 38 - 38: Oo0oO0ooo % oOOO0OOooOoO0Oo + i11iIiiIii + IiiIII111ii + II / i11iIiiIii
 o0OOOOOo0 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( url ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&iconimage=" + urllib . quote_plus ( iconimage ) + "&fanart=" + urllib . quote_plus ( fanart )
 ooOOooOo0O = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 I11iiiii1II = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 I11iiiii1II . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "credits" : credits } )
 I11iiiii1II . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  oooOoO = [ ]
  if showcontext == 'source' :
   if name in str ( II11iiii1Ii ) :
    oooOoO . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'download' :
   oooOoO . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   oooOoO . append ( ( 'Remove from Add-on Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 62 - 62: oO / o0OO0 + o00 % II / o00 + O0OOo
  if not name in OooO0 :
   oooOoO . append ( ( 'Add to Add-on Favorites' , 'XBMC.RunPlugin(%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) , mode ) ) )
  I11iiiii1II . addContextMenuItems ( oooOoO )
 ooOOooOo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0OOOOOo0 , listitem = I11iiiii1II , isFolder = True )
 if 2 - 2: i11iIiiIii - oOOO0OOooOoO0Oo + o00ooo0 % IiiIIiiI11 * oooOOOOO
 return ooOOooOo0O
def Ooo000O00 ( url , title , media_type = 'video' ) :
 if 36 - 36: oO % i11iIiiIii
 if 47 - 47: I1iII1iiII + o0OO0 . I1i1iI1i * II1Iiii1111i . IiiIIiiI11 / I1iII1iiII
 import youtubedl
 if not url == '' :
  if media_type == 'audio' :
   youtubedl . single_YD ( url , download = True , audio = True )
  else :
   youtubedl . single_YD ( url , download = True )
 elif xbmc . Player ( ) . isPlaying ( ) == True :
  import YDStreamExtractor
  if YDStreamExtractor . isDownloading ( ) == True :
   if 50 - 50: oOOO0OOooOoO0Oo / I1iII1iiII % OoOO
   YDStreamExtractor . manageDownloads ( )
  else :
   oOOOOO0Ooooo = xbmc . Player ( ) . getPlayingFile ( )
   if 57 - 57: oooOOOOO - OoOO
   oOOOOO0Ooooo = oOOOOO0Ooooo . split ( '|User-Agent=' ) [ 0 ]
   iiIiii = { 'url' : oOOOOO0Ooooo , 'title' : title , 'media_type' : media_type }
   youtubedl . single_YD ( '' , download = True , dl_info = iiIiii )
 else :
  xbmc . executebuiltin ( "XBMC.Notification(DOWNLOAD,First Play [COLOR yellow]WHILE playing download[/COLOR] ,10000)" )
  if 68 - 68: Oo0oO0ooo % O0OOo / oOOO0OOooOoO0Oo + oOOO0OOooOoO0Oo - oOOO0OOooOoO0Oo . o00ooo0
def oOO00ooOOo ( site_name , search_term = None ) :
 II11Iiii = ''
 if os . path . exists ( I1 ) == False or i1IIi11111i . getSetting ( 'clearseachhistory' ) == 'true' :
  oO0Oo0O0 ( I1 , '' )
  i1IIi11111i . setSetting ( "clearseachhistory" , "false" )
 if site_name == 'history' :
  iiI11i1II = oo0o ( I1 )
  IIIii1II1II = re . compile ( '(.+?):(.*?)(?:\r|\n)' ) . findall ( iiI11i1II )
  if 20 - 20: O0OOo
  for i1I1iI , search_term in IIIii1II1II :
   if 'plugin://' in search_term :
    oO0Oo ( search_term , i1I1iI , II11Iiii , '' , '' , '' , '' , '' , None , '' , total = int ( len ( IIIii1II1II ) ) )
   else :
    i1Iii1i1I ( i1I1iI + ':' + search_term , i1I1iI , 26 , iI111I11I1I1 , OOooO0OOoo , '' , '' , '' , '' )
 if not search_term :
  oO0Oo0O0o = xbmc . Keyboard ( '' , 'Enter Search Term' )
  oO0Oo0O0o . doModal ( )
  if ( oO0Oo0O0o . isConfirmed ( ) == False ) :
   return
  search_term = oO0Oo0O0o . getText ( )
  if len ( search_term ) == 0 :
   return
 search_term = search_term . replace ( ' ' , '+' )
 search_term = search_term . encode ( 'utf-8' )
 if 'youtube' in site_name :
  if 3 - 3: o00ooo0 * I1iII1iiII . Oo0ooO0oo0oO . iiiiIi11i - o00
  import _ytplist
  if 81 - 81: Oo0ooO0oo0oO - o0O / Oo0ooO0oo0oO / iiiiIi11i
  I1I1IIiiii1ii = { }
  I1I1IIiiii1ii = _ytplist . YoUTube ( 'searchYT' , youtube = search_term , max_page = 4 , nosave = 'nosave' )
  IIIIiIiIi1 = len ( I1I1IIiiii1ii )
  for i1II1 in I1I1IIiiii1ii :
   try :
    i1I1iI = I1I1IIiiii1ii [ i1II1 ] [ 'title' ]
    o0OoOO000ooO0 = I1I1IIiiii1ii [ i1II1 ] [ 'date' ]
    try :
     oOo0Oi1i = I1I1IIiiii1ii [ i1II1 ] [ 'desc' ]
    except Exception :
     oOo0Oi1i = 'UNAVAIABLE'
     if 60 - 60: I1i1iI1i . i1iIIi1 % Oo0ooO0oo0oO - oOOO0OOooOoO0Oo
    oOo0O = 'plugin://plugin.video.youtube/play/?video_id=' + I1I1IIiiii1ii [ i1II1 ] [ 'url' ]
    II11Iiii = 'http://img.youtube.com/vi/' + I1I1IIiiii1ii [ i1II1 ] [ 'url' ] + '/0.jpg'
    oO0Oo ( oOo0O , i1I1iI , II11Iiii , '' , '' , '' , '' , '' , None , '' , IIIIiIiIi1 )
   except Exception :
    oOOO00o ( 'This item is ignored::' )
  oooOo = site_name + ':' + search_term + '\n'
  oO0Oo0O0 ( os . path . join ( oo , 'history' ) , oooOo , append = True )
 elif 'dmotion' in site_name :
  oOoO0Oo0 = "https://api.dailymotion.com"
  if 7 - 7: II + oooOOOOO
  import _DMsearch
  IiiIIiI1iI1 = str ( i1IIi11111i . getSetting ( 'familyFilter' ) )
  _DMsearch . listVideos ( oOoO0Oo0 + "/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=" + search_term + "&sort=relevance&limit=100&family_filter=" + IiiIIiI1iI1 + "&localization=en_EN&page=1" )
  if 86 - 86: I1iII1iiII / oooOOOOO * Oo0ooO0oo0oO
  oooOo = site_name + ':' + search_term + '\n'
  oO0Oo0O0 ( os . path . join ( oo , 'history' ) , oooOo , append = True )
 elif 'IMDBidplay' in site_name :
  oOoO0Oo0 = "http://www.omdbapi.com/?t="
  oOo0O = oOoO0Oo0 + search_term
  if 67 - 67: O0OOo * O0OOo / II1Iiii1111i * OoOO + o00
  iIiii = dict ( { 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.3; rv:33.0) Gecko/20100101 Firefox/33.0' , 'Referer' : 'http://joker.org/' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/json;charset=utf-8' , 'Accept' : 'application/json, text/plain, */*' } )
  if 79 - 79: I1iII1iiII
  O000Oo0o = requests . get ( oOo0O , headers = iIiii )
  III1ii1iII = O000Oo0o . json ( )
  iIi1 = III1ii1iII [ 'Response' ]
  if iIi1 == 'True' :
   ooo0Oooooo = III1ii1iII [ 'imdbID' ]
   i1I1iI = III1ii1iII [ 'Title' ] + III1ii1iII [ 'Released' ]
   O00 = xbmcgui . Dialog ( )
   ii111i1iI = O00 . yesno ( 'Check Movie Title' , 'PLAY :: %s ?' % i1I1iI )
   if ii111i1iI :
    oOo0O = 'plugin://plugin.video.pulsar/movie/' + ooo0Oooooo + '/play'
    oooOo = i1I1iI + ':' + oOo0O + '\n'
    oO0Oo0O0 ( I1 , oooOo , append = True )
    return oOo0O
  else :
   xbmc . executebuiltin ( "XBMC.Notification(SimpleKore,No IMDB match found ,7000," + iI111I11I1I1 + ")" )
   if 59 - 59: i11iIiiIii . OoOO / IiiIIiiI11 * O0OOo + OoOO
def Ii1I1i1ii1I1 ( string ) :
 if isinstance ( string , basestring ) :
  if isinstance ( string , unicode ) :
   string = string . encode ( 'ascii' , 'ignore' )
 return string
def O0oo00oOOO0o ( string , encoding = 'utf-8' ) :
 if isinstance ( string , basestring ) :
  if not isinstance ( string , unicode ) :
   string = unicode ( string , encoding , 'ignore' )
 return string
def II1i ( s ) : return "" . join ( filter ( lambda i1i : ord ( i1i ) < 128 , s ) )
if 6 - 6: i1iIIi1 * i1iIIi1 * iiiiIi11i / oO + iiiiIi11i
def OOOOoO00O ( command ) :
 III1ii1iII = ''
 try :
  III1ii1iII = xbmc . executeJSONRPC ( O0oo00oOOO0o ( command ) )
 except UnicodeEncodeError :
  III1ii1iII = xbmc . executeJSONRPC ( Ii1I1i1ii1I1 ( command ) )
  if 27 - 27: O0OOo * I1iII1iiII . I1iII1iiII
 return O0oo00oOOO0o ( III1ii1iII )
 if 87 - 87: i1iIIi1 / oOOO0OOooOoO0Oo - I1i1iI1i
 if 56 - 56: iiiiIi11i
def OoO ( ) :
 iIIIII1iI = xbmc . getSkinDir ( )
 if iIIIII1iI == 'skin.confluence' :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif iIIIII1iI == 'skin.aeon.nox' :
  xbmc . executebuiltin ( 'Container.SetViewMode(511)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  if 18 - 18: I1i1iI1i - iiiiIi11i
  if 85 - 85: oooOOOOO - iiiiIi11i * i11iIiiIii . I1iII1iiII
def i11i1O00oo00OOOO ( url ) :
 IiIi1II111I = O0oo00oOOO0o ( '{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}' ) % url
 if 80 - 80: oooOOOOO / oO
 iIIi1i11 = json . loads ( OOOOoO00O ( IiIi1II111I ) )
 for OOOOOoo0 in iIIi1i11 [ 'result' ] [ 'files' ] :
  url = OOOOOoo0 [ 'file' ]
  i1I1iI = II1i ( OOOOOoo0 [ 'label' ] )
  II11Iiii = II1i ( OOOOOoo0 [ 'thumbnail' ] )
  try :
   o0OO00oO = II1i ( OOOOOoo0 [ 'fanart' ] )
  except Exception :
   o0OO00oO = ''
  try :
   o0OoOO000ooO0 = OOOOOoo0 [ 'year' ]
  except Exception :
   o0OoOO000ooO0 = ''
  try :
   iI1Iii11i1 = OOOOOoo0 [ 'episode' ]
   II11iIIii = OOOOOoo0 [ 'season' ]
   if iI1Iii11i1 == - 1 or II11iIIii == - 1 :
    oOo0Oi1i = ''
   else :
    oOo0Oi1i = '[COLOR yellow] S' + str ( II11iIIii ) + '[/COLOR][COLOR hotpink] E' + str ( iI1Iii11i1 ) + '[/COLOR]'
  except Exception :
   oOo0Oi1i = ''
  try :
   oooOo0Ooo0oo = OOOOOoo0 [ 'studio' ]
   if oooOo0Ooo0oo :
    oOo0Oi1i += '\n Studio:[COLOR steelblue] ' + oooOo0Ooo0oo [ 0 ] + '[/COLOR]'
  except Exception :
   oooOo0Ooo0oo = ''
   if 66 - 66: iiiiIi11i
  if OOOOOoo0 [ 'filetype' ] == 'file' :
   oO0Oo ( url , i1I1iI , II11Iiii , o0OO00oO , oOo0Oi1i , '' , o0OoOO000ooO0 , '' , None , '' , total = len ( iIIi1i11 [ 'result' ] [ 'files' ] ) )
   if 52 - 52: o00ooo0 * OoOO
   if 12 - 12: iiiiIi11i + i1iIIi1 * I1iII1iiII . o00ooo0
  else :
   i1Iii1i1I ( i1I1iI , url , 53 , II11Iiii , o0OO00oO , oOo0Oi1i , '' , o0OoOO000ooO0 , '' )
   if 71 - 71: oOOO0OOooOoO0Oo - Oo0oO0ooo - oO
   if 28 - 28: o0O
def oO0Oo ( url , name , iconimage , fanart , description , genre , date , showcontext , playlist , regexs , total , setCookie = "" ) :
 if 7 - 7: Oo0oO0ooo % i1iIIi1 * o00
 oooOoO = [ ]
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 ooOOooOo0O = True
 if 58 - 58: i1iIIi1 / IiiIIiiI11 + o0OO0 % IiiIII111ii - OoOO
 if regexs :
  II1iII1i1i = '17'
  if 63 - 63: oO * IiiIIiiI11
  oooOoO . append ( ( '[COLOR white]!!Download Currently Playing!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif any ( x in url for x in iI1Ii11111iIi ) and url . startswith ( 'http' ) :
  II1iII1i1i = '19'
  if 22 - 22: O0OOo * iiiiIi11i * o0O
  oooOoO . append ( ( '[COLOR white]!!Download Currently Playing!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  II1iII1i1i = '18'
  if 77 - 77: o0OO0 + Oo0oO0ooo
  oooOoO . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if i1IIi11111i . getSetting ( 'dlaudioonly' ) == 'true' :
   oooOoO . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if 47 - 47: oO
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
  url = 'plugin://plugin.video.pulsar/play?uri=' + url
  II1iII1i1i = '12'
  if 75 - 75: i1iIIi1 % i11iIiiIii + o0O
 else :
  II1iII1i1i = '12'
  if 92 - 92: o00 % iiiiIi11i
  oooOoO . append ( ( '[COLOR white]!!Download Currently Playing!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 o0OOOOOo0 = sys . argv [ 0 ] + "?"
 oo00ooooOOo00 = False
 if 16 - 16: i11iIiiIii / I1iII1iiII % oO
 if playlist :
  if i1IIi11111i . getSetting ( 'add_playlist' ) == "false" :
   o0OOOOOo0 += "url=" + urllib . quote_plus ( url ) + "&mode=" + II1iII1i1i
  else :
   o0OOOOOo0 += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR magenta] (' + str ( len ( playlist ) ) + ' items )[/COLOR]'
   oo00ooooOOo00 = True
 else :
  o0OOOOOo0 += "url=" + urllib . quote_plus ( url ) + "&mode=" + II1iII1i1i
 if regexs :
  o0OOOOOo0 += "&regexs=" + regexs
 if not setCookie == '' :
  o0OOOOOo0 += "&setCookie=" + urllib . quote_plus ( setCookie )
  if 84 - 84: IiiIIiiI11 - I1i1iI1i * iiiiIi11i / oooOOOOO . oooOOOOO
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 I11iiiii1II = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 I11iiiii1II . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 I11iiiii1II . setProperty ( "Fanart_Image" , fanart )
 if 93 - 93: iiiiIi11i / II + Oo0ooO0oo0oO
 if ( not oo00ooooOOo00 ) and not any ( x in url for x in i1i1II ) :
  if regexs :
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) :
    if 20 - 20: i1iIIi1 / IiiIII111ii % OoOO / o0O + Oo0ooO0oo0oO
    I11iiiii1II . setProperty ( 'IsPlayable' , 'true' )
  else :
   I11iiiii1II . setProperty ( 'IsPlayable' , 'true' )
 else :
  oOOO00o ( 'NOT setting isplayable' + url )
  if 57 - 57: Oo0oO0ooo / oOOO0OOooOoO0Oo
 if showcontext :
  oooOoO = [ ]
  if showcontext == 'fav' :
   oooOoO . append (
 ( 'Remove from Add-on Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in OooO0 :
   iiIiII = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if playlist :
    iiIiII += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    iiIiII += "&regexs=" + regexs
   oooOoO . append ( ( 'Add to Add-on Favorites' , 'XBMC.RunPlugin(%s)' % iiIiII ) )
  I11iiiii1II . addContextMenuItems ( oooOoO )
  if 7 - 7: I1i1iI1i - I1iII1iiII . O0OOo / o0O * Oo0oO0ooo
 if not playlist is None :
  if i1IIi11111i . getSetting ( 'add_playlist' ) == "false" :
   O0O0 = name . split ( ') ' ) [ 1 ]
   O0oO0o0OOOOOO = [
 ( 'Play ' + O0O0 + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( O0O0 ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
   I11iiiii1II . addContextMenuItems ( O0oO0o0OOOOOO )
   if 24 - 24: I1iII1iiII * i1iIIi1 - IiiIIiiI11 / oooOOOOO
   if 62 - 62: I1i1iI1i
 ooOOooOo0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = o0OOOOOo0 , listitem = I11iiiii1II , totalItems = total )
 if 30 - 30: I1iII1iiII
 return ooOOooOo0O
 if 4 - 4: oOOO0OOooOoO0Oo - Oo0ooO0oo0oO % II1Iiii1111i / Oo0oO0ooo % II1Iiii1111i * o0OO0
def IiI1I ( url , name , iconimage , setresolved = True ) :
 if setresolved :
  I11iiiii1II = xbmcgui . ListItem ( name , iconImage = iconimage )
  I11iiiii1II . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
  I11iiiii1II . setProperty ( "IsPlayable" , "true" )
  I11iiiii1II . setPath ( str ( url ) )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , I11iiiii1II )
 else :
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + url + ')' )
  if 25 - 25: II1Iiii1111i % Oo0ooO0oo0oO + i11iIiiIii + iiiiIi11i * OoOO
  if 64 - 64: I1iII1iiII
  if 10 - 10: oOOO0OOooOoO0Oo % iiiiIi11i / Oo0ooO0oo0oO % IiiIIiiI11
  if 25 - 25: o0OO0 / o00ooo0
def ii1IIi111 ( link ) :
 oOo0O = urllib . urlopen ( link )
 oo0OoOO0000 = oOo0O . read ( )
 oOo0O . close ( )
 i11Ii1iIIIIi = oo0OoOO0000 . split ( "Jetzt" )
 iiiO000OOO = i11Ii1iIIIIi [ 1 ] . split ( 'programm/detail.php?const_id=' )
 o0 = iiiO000OOO [ 1 ] . split ( '<br /><a href="/' )
 IIi1 = o0 [ 0 ] [ 40 : len ( o0 [ 0 ] ) ]
 O00O00o = iiiO000OOO [ 2 ] . split ( "</a></p></div>" )
 I11IiI1iI = O00O00o [ 0 ] [ 17 : len ( O00O00o [ 0 ] ) ]
 I11IiI1iI = I11IiI1iI . encode ( 'utf-8' )
 return "  - " + I11IiI1iI + " - " + IIi1
 if 96 - 96: oooOOOOO . oOOO0OOooOoO0Oo - O0OOo + Oo0oO0ooo * o00ooo0 / IiiIII111ii
 if 26 - 26: oO * I1i1iI1i
def i1iI11i1IIi ( url , regex ) :
 III1ii1iII = IIII ( url )
 try :
  i1II1 = re . findall ( regex , III1ii1iII ) [ 0 ]
  return i1II1
 except :
  oOOO00o ( 'regex failed' )
  oOOO00o ( regex )
  return
  if 31 - 31: IiiIIiiI11 * II1Iiii1111i . oooOOOOO
  if 35 - 35: IiiIIiiI11
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 94 - 94: II / i11iIiiIii % iiiiIi11i
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_UNSORTED )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_LABEL )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_DATE )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_GENRE )
except :
 pass
 if 70 - 70: IiiIIiiI11 - I1i1iI1i / OoOO % OoOO
IIii1III = i11 ( )
if 95 - 95: OoOO % OoOO . oooOOOOO
oOo0O = None
i1I1iI = None
II1iII1i1i = None
i11i1iIiii = None
O0ooO00ooOO0o = None
o0OO00oO = OOooO0OOoo
i11i1iIiii = None
III1ii = None
iiI = None
if 38 - 38: O0OOo + o00
try :
 oOo0O = urllib . unquote_plus ( IIii1III [ "url" ] ) . decode ( 'utf-8' )
except :
 pass
try :
 i1I1iI = urllib . unquote_plus ( IIii1III [ "name" ] )
except :
 pass
try :
 O0ooO00ooOO0o = urllib . unquote_plus ( IIii1III [ "iconimage" ] )
except :
 pass
try :
 o0OO00oO = urllib . unquote_plus ( IIii1III [ "fanart" ] )
except :
 pass
try :
 II1iII1i1i = int ( IIii1III [ "mode" ] )
except :
 pass
try :
 i11i1iIiii = eval ( urllib . unquote_plus ( IIii1III [ "playlist" ] ) . replace ( '||' , ',' ) )
except :
 pass
try :
 III1ii = int ( IIii1III [ "fav_mode" ] )
except :
 pass
try :
 iiI = IIii1III [ "regexs" ]
except :
 pass
 if 68 - 68: iiiiIi11i
oOOO00o ( "Mode: " + str ( II1iII1i1i ) )
if not oOo0O is None :
 oOOO00o ( "URL: " + str ( oOo0O . encode ( 'utf-8' ) ) )
oOOO00o ( "Name: " + str ( i1I1iI ) )
if 76 - 76: O0OOo
if II1iII1i1i == None :
 oOOO00o ( "Index" )
 ii1I1i1I ( )
 if 99 - 99: Oo0oO0ooo
elif II1iII1i1i == 1 :
 oOOO00o ( "getData" )
 OOoo0O0 ( oOo0O , o0OO00oO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 1 - 1: oooOOOOO * o00 * o00ooo0 + I1i1iI1i
elif II1iII1i1i == 2 :
 oOOO00o ( "getChannelItems" )
 oOoO0 ( i1I1iI , oOo0O , o0OO00oO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 90 - 90: oOOO0OOooOoO0Oo % I1i1iI1i - I1i1iI1i . o0O / oO + IiiIIiiI11
elif II1iII1i1i == 3 :
 oOOO00o ( "getSubChannelItems" )
 I1ii11 ( i1I1iI , oOo0O , o0OO00oO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 89 - 89: II1Iiii1111i
elif II1iII1i1i == 4 :
 oOOO00o ( "getFavorites" )
 iI111II1ii ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 87 - 87: IiiIII111ii % I1i1iI1i
elif II1iII1i1i == 5 :
 oOOO00o ( "addFavorite" )
 try :
  i1I1iI = i1I1iI . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  i1I1iI = i1I1iI . split ( '  - ' ) [ 0 ]
 except :
  pass
 IIiii11ii1i ( i1I1iI , oOo0O , O0ooO00ooOO0o , o0OO00oO , III1ii )
 if 62 - 62: o00ooo0 + II / IiiIII111ii * i11iIiiIii
elif II1iII1i1i == 6 :
 oOOO00o ( "rmFavorite" )
 try :
  i1I1iI = i1I1iI . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  i1I1iI = i1I1iI . split ( '  - ' ) [ 0 ]
 except :
  pass
 I1ii1Ii1 ( i1I1iI )
 if 37 - 37: IiiIII111ii
elif II1iII1i1i == 7 :
 oOOO00o ( "addSource" )
 Ooo ( oOo0O )
 if 33 - 33: o00ooo0 - iiiiIi11i - o00ooo0
elif II1iII1i1i == 8 :
 oOOO00o ( "rmSource" )
 OOooo0oOO0O ( i1I1iI )
 if 94 - 94: i1iIIi1 * IiiIIiiI11 * OoOO / Oo0oO0ooo . i1iIIi1 - Oo0oO0ooo
elif II1iII1i1i == 9 :
 oOOO00o ( "download_file" )
 O0OooOO ( i1I1iI , oOo0O )
 if 13 - 13: oO / i1iIIi1 - o00ooo0 / oO . I1iII1iiII
elif II1iII1i1i == 10 :
 oOOO00o ( "getCommunitySources" )
 OoOOoOooooOOo ( )
 if 22 - 22: iiiiIi11i - IiiIIiiI11 + oOOO0OOooOoO0Oo . oooOOOOO * I1iII1iiII
elif II1iII1i1i == 11 :
 oOOO00o ( "addSource" )
 Ooo ( oOo0O )
 if 26 - 26: o0O * Oo0oO0ooo . IiiIIiiI11
elif II1iII1i1i == 12 :
 oOOO00o ( "setResolvedUrl" )
 if not oOo0O . startswith ( "plugin://plugin" ) or not any ( x in oOo0O for x in i1i1II ) :
  i1II1 = xbmcgui . ListItem ( path = oOo0O )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1II1 )
 else :
  print 'Not setting setResolvedUrl'
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + oOo0O + ')' )
  if 10 - 10: oOOO0OOooOoO0Oo * II1Iiii1111i % I1i1iI1i - IiiIIiiI11 % I1i1iI1i
  if 65 - 65: IiiIII111ii * o0O / iiiiIi11i . IiiIIiiI11
elif II1iII1i1i == 13 :
 oOOO00o ( "play_playlist" )
 I1IIi ( i1I1iI , i11i1iIiii )
 if 94 - 94: I1i1iI1i . II * i11iIiiIii - Oo0oO0ooo . IiiIII111ii
elif II1iII1i1i == 14 :
 oOOO00o ( "get_xml_database" )
 oOooOOo0o ( oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 98 - 98: oO + oooOOOOO
elif II1iII1i1i == 15 :
 oOOO00o ( "browse_xml_database" )
 oOooOOo0o ( oOo0O , True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 52 - 52: I1i1iI1i / o00 - oOOO0OOooOoO0Oo . IiiIII111ii
elif II1iII1i1i == 16 :
 oOOO00o ( "browse_community" )
 OoOOoOooooOOo ( True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 50 - 50: o0O - IiiIII111ii - IiiIIiiI11
elif II1iII1i1i == 17 :
 oOOO00o ( "getRegexParsed" )
 oOo0O , O0Oo = iIIIII1iiiiII ( iiI , oOo0O )
 if oOo0O :
  IiI1I ( oOo0O , i1I1iI , O0ooO00ooOO0o , O0Oo )
 else :
  xbmc . executebuiltin ( "XBMC.Notification(Furious Streams ,Failed to extract regex. - " + "this" + ",4000," + iI111I11I1I1 + ")" )
elif II1iII1i1i == 18 :
 oOOO00o ( "youtubedl" )
 try :
  import youtubedl
 except Exception :
  xbmc . executebuiltin ( "XBMC.Notification(Furious Streams,Please [COLOR yellow]install the Youtube Addon[/COLOR] module ,10000," ")" )
 OOooO0o0 = youtubedl . single_YD ( oOo0O )
 IiI1I ( OOooO0o0 , i1I1iI , O0ooO00ooOO0o )
elif II1iII1i1i == 19 :
 oOOO00o ( "Genesiscommonresolvers" )
 IiI1I ( I1i111iiIIIi ( oOo0O ) , i1I1iI , O0ooO00ooOO0o , True )
 if 60 - 60: o0O * II
elif II1iII1i1i == 21 :
 oOOO00o ( "download current file using youtube-dl service" )
 Ooo000O00 ( '' , i1I1iI , 'video' )
elif II1iII1i1i == 23 :
 oOOO00o ( "get info then download" )
 Ooo000O00 ( oOo0O , i1I1iI , 'video' )
elif II1iII1i1i == 24 :
 oOOO00o ( "Audio only youtube download" )
 Ooo000O00 ( oOo0O , i1I1iI , 'audio' )
elif II1iII1i1i == 25 :
 oOOO00o ( "YouTube/DMotion" )
 oOO00ooOOo ( oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif II1iII1i1i == 26 :
 oOOO00o ( "YouTube/DMotion From Search History" )
 i1I1iI = i1I1iI . split ( ':' )
 oOO00ooOOo ( oOo0O , search_term = i1I1iI [ 1 ] )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif II1iII1i1i == 27 :
 oOOO00o ( "Using IMDB id to play in Pulsar" )
 oO0O0o0o000 = oOO00ooOOo ( oOo0O )
 xbmc . Player ( ) . play ( oO0O0o0o000 )
elif II1iII1i1i == 30 :
 OO0oo0O ( i1I1iI , oOo0O , O0ooO00ooOO0o , o0OO00oO )
elif II1iII1i1i == 31 :
 oOoO00O0 ( oOo0O , O0ooO00ooOO0o , o0OO00oO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif II1iII1i1i == 32 :
 IiI1iiiIii ( oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 6 - 6: o00 / II + IiiIII111ii - Oo0oO0ooo * oO + II
elif II1iII1i1i == 40 :
 oo0oOoo ( )
 OoO ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif II1iII1i1i == 41 :
 iI ( oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 76 - 76: o0OO0 - OoOO % i1iIIi1
elif II1iII1i1i == 53 :
 oOOO00o ( "Requesting JSON-RPC Items" )
 i11i1O00oo00OOOO ( oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 40 - 40: oooOOOOO
elif II1iII1i1i == 70 :
 scrape2 ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 59 - 59: IiiIIiiI11 * OoOO + oO . o0O / I1iII1iiII
elif II1iII1i1i == 71 :
 play2 ( i1I1iI , oOo0O )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) 

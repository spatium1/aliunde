import xbmcaddon
import base64

MainBase = base64.b64decode ('aHR0cDovL2JyZXR0dXNidWlsZHMuY29tL0ZURkEvRnVyaW91c0lQVFYvTUFJTi5YTUw=')
addon = xbmcaddon.Addon('plugin.video.furiousstreams')
import re
import requests
import xbmc



domain_movies = 'http://mythewatchseries.com/movies'
sources = []


        

def scrape_movie():
    html = requests.get(domain_movies).text
    block = re.compile('<div class="movies_index">(.+?)<div class="pagination">',re.DOTALL).findall(html)
    match = re.compile('<li rel="tooltip".+?class="name">(.+?)</div>.+?</div><div class="date">(.+?)</div><div class="des">(.+?)</div></div>.+?<a href="(.+?)">.+?<img src="(.+?)" alt=".+?" />.+?<div class="season">(.+?)</div>',re.DOTALL).findall(block)
    for name, date, desc, url, image, qual in block :
'''
                xbmc.log('~~~~~~~~~~~~~~~~MATCHED~~~~~~~~~~~~~~~~~~')
                url = self.base_link + page
                html2 = requests.get(url).text
                match2 = re.compile('<li><span>Latest Episode:  </span>.+?<a href="/(.+?)" title=".+?">(.+?)</a>',re.DOTALL).findall(html2)
                for playlink_page,qual in match2:
                    xbmc.log('~~~~~~~~~~~~~~~~MATCHED2~~~~~~~~~~~~~~~~~~')
                    quality = qual.replace(' ','')
                    url2 = self.base_link + playlink_page
                    html3 = requests.get(url2).text
                    match3 = re.compile('data-video="(.+?)" >(.+?)<span>',re.DOTALL).findall(html3.replace('">','" >'))
                    for link,source in match3:
                        xbmc.log('~~~~~~~~~~~~~~~~FETCHING SOURCE~~~~~~~~~~~~~~~~~~')
                        if 'OpenUpload' in source:
                            self.sources.append({'source': 'openload.co', 'quality': quality, 'scraper': self.name, 'url': link,'direct': False})
                        elif 'Thevideo' in source:
                            self.sources.append({'source': 'thevideo.me', 'quality': quality, 'scraper': self.name, 'url': link,'direct': False})
                        else:
                            if 'Server HD' or 'Server Backup' in source:
                                html4 = requests.get(link).text
                                match4 = re.compile("<source src='(.+?)' type",re.DOTALL).findall(html4)
                                for glink in match4:
                                    self.sources.append({'source': 'The Watchseries', 'quality': quality, 'scraper': self.name, 'url': glink,'direct': True}) 

        except:
            pass
        return self.sources

'''
import xbmcaddon

MainBase = 'http://genietvcunts.co.uk/bamffff/BAMF.xml'
addon = xbmcaddon.Addon('plugin.video.Back_In_Time')

import xbmcaddon

MainBase = 'http://www.goodfellasteam.com/goodfellas2/gf2main.xml'
addon = xbmcaddon.Addon('plugin.video.goodfellas')
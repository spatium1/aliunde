# -*- coding: utf-8 -*-
import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os,base64,cloudflare,net,dandy
import xbmcaddon
from addon.common.addon import Addon
import requests

net = net.Net()
s = requests.session() 

User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.toonsrus_gw'
selfAddon = xbmcaddon.Addon(id=addon_id)
datapath= xbmc.translatePath(selfAddon.getAddonInfo('profile'))
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id + '/resources/icons/'))
ICON = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
FANART = xbmc.translatePath(os.path.join('special://home/addons/' + addon_id , 'fanart.jpg'))
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
try:os.mkdir(datapath)
except:pass
file_var = open(xbmc.translatePath(os.path.join(datapath, 'cookie.lwp')), "a")
cookie_file = os.path.join(os.path.join(datapath,''), 'cookie.lwp')

BASEURL = 'https://kimcartoon.io'
menu_type = selfAddon.getSetting('enable_dial')

def MENU():
    addDir('[B][COLOR white]Cartoon List[/COLOR][/B]',BASEURL + '/CartoonList',5,ART + 'cartoonlist.jpg',FANART,'')
    addDir('[B][COLOR white]Newest Cartoon[/COLOR][/B]',BASEURL + '/CartoonList/Newest',5,ART + 'newest.jpg',FANART,'')
    addDir('[B][COLOR white]Latest Update[/COLOR][/B]',BASEURL + '/CartoonList/LatestUpdate',5,ART + 'latest.jpg',FANART,'')
    addDir('[B][COLOR white]Most Popular[/COLOR][/B]',BASEURL + '/CartoonList/MostPopular',5,ART + 'popular.jpg',FANART,'')
    addDir('[B][COLOR white]Alpha[/COLOR][/B]',BASEURL + '/CartoonList',4,ART + 'alpha.jpg',FANART,'')
    addDir('[B][COLOR white]Genres[/COLOR][/B]',BASEURL + '/CartoonList',3,ART + 'genres.jpg',FANART,'')
    addDir('[B][COLOR green]Search[/COLOR][/B]','url',8,ART + 'search.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')
    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item.+?class=\'title\'>(.+?)</p>.+?class=\'description\'>(.+?)</p>.+?href="(.+?)".+?src="(.+?)"',re.DOTALL).findall(OPEN)
    for name,desc,url,icon in Regex:
        name = name.replace('<em>','').replace('</em>','')
        desc=desc.replace('<p>','')
        icon=icon+"|User-Agent=Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0&Cookie=%s"%getCookiesString()
        if menu_type=='true':
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,FANART,desc)
        else:    
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,desc)
    np = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(OPEN)
    for url,name in np:
        if '&gt;&gt;' in name:
            addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,5,ART + 'nextpage.jpg',FANART,'')
    setView('movies', 'movie-view')
    
def Genres(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<div class="list_gender full">(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        name = name.replace('cartoon','cartoons').title()    
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,5,ART + 'genres.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Alpha(url):
    OPEN = Open_Url(url)
    base = url
    Regex = re.compile('<div class="alphabet full a_center">(.+?)</div>',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'All' not in name:    
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,base+url,5,ART + 'alpha.jpg',FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Search():
        keyb = xbmc.Keyboard('', 'Search')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText().replace(' ','%20')
                url  = BASEURL + '/Search/?s=' + search
                Get_content(url)

def Get_epis(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<h3>.+?href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(OPEN)
    Regex = list(reversed(Regex))
    for url,name in Regex:
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,101,iconimage,FANART,description)
    setView('movies', 'movie-view')

def RESOLVE(url,name):
    bollox = name
    bollox = bollox.replace('[B][COLOR white]','').replace('[/COLOR][/B]','')
    res_quality = []
    stream_url = []
    quality = ''
    OPEN = Open_Url(url)
    match = re.compile('<h3>.+?href="(.+?)".+?>(.+?)</a>',re.DOTALL).findall(OPEN)
    for link,label in match:
        label = label.replace(bollox,'')
        quality = '[B][COLOR white]%s[/COLOR][/B]' %label        
        res_quality.append(quality)
        stream_url.append(link)
    if len(match) >1:
            dialog = xbmcgui.Dialog()
            ret = dialog.select('Please Select Episode',res_quality)
            if ret == -1:
                return
            elif ret > -1:
                url = stream_url[ret]
    else:
        url = re.compile('<h3>.+?href="(.+?)"',re.DOTALL).findall(OPEN)[0]
    try:
        MOV = Open_Url(url)
        refer=url
        epID = re.compile("var episode_id = '(.+?)'",re.DOTALL).findall(MOV)[0]
        epID = BASEURL + '/ajax/anime/load_episodes?episode_id=' + epID
        Link = Open_Url(epID)
        player = re.compile('"value":"(.+?)"',re.DOTALL).findall(Link)[0] 
        player = player.replace('\/','/')
        player = 'https:' + player
        headers = {'Accept':'application/json, text/javascript, */*; q=0.01',
                        'Accept-Encoding':'gzip',
                        'Accept-Language':'en-US,en;q=0.8',
                        'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
                        'Origin':'https://kimcartoon.io',
                        'Referer':url,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',
                        'X-Requested-With':'XMLHttpRequest'}

        end=requests.get(player,headers=headers,allow_redirects=True).content
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(end)[0] 
        url = url.replace('\/','/') 
        url = url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+refer
        #print 'final_URL >>>>>>>>>>>>>>>>>>>>>>>>>> '+url         
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass

def alt_RESOLVE(url):
    try:
        MOV = Open_Url(url)
        refer = url
        epID = re.compile("var episode_id = '(.+?)'",re.DOTALL).findall(MOV)[0]
        epID = BASEURL + '/ajax/anime/load_episodes?episode_id=' + epID
        Link = Open_Url(epID)
        player = re.compile('"value":"(.+?)"',re.DOTALL).findall(Link)[0] 
        player = player.replace('\/','/')
        player = 'https:' + player
        headers = {'Accept':'application/json, text/javascript, */*; q=0.01',
                        'Accept-Encoding':'gzip',
                        'Accept-Language':'en-US,en;q=0.8',
                        'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
                        'Origin':'https://kimcartoon.io',
                        'Referer':url,
                        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36',
                        'X-Requested-With':'XMLHttpRequest'}

        end=requests.get(player,headers=headers,allow_redirects=True).content
        url = re.compile('"file":"(.+?)"',re.DOTALL).findall(end)[0] 
        url = url.replace('\/','/') 
        url = url+'|User-Agent=Mozilla/5.0 (Windows NT 10.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/54.0.2840.71 Safari/537.36&Referer='+refer
        #print 'alt END_URL >>>>>>>>>>>>>>>>>>>>>>>>>> '+url        
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:pass
    
def get_params():
	param=[]
	paramstring=sys.argv[2]
	if len(paramstring)>=2:
		params=sys.argv[2]
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:
				param[splitparams[0]]=splitparams[1]
	return param

def Open_Url(url):
        try:
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
        except:
                import cloudflare
                cloudflare.createCookie(url,cookie_file,'Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0')
                net.set_cookies(cookie_file)
                link = net.http_GET(url).content
                link = cleanHex(link)
                return link
	
def cleanHex(text):
    def fixup(m):
        text = m.group(0)
        if text[:3] == "&#x": return unichr(int(text[3:-1], 16)).encode('utf-8')
        else: return unichr(int(text[2:-1])).encode('utf-8')
    try :return re.sub("(?i)&#\w+;", fixup, text.decode('ISO-8859-1').encode('utf-8'))
    except:return re.sub("(?i)&#\w+;", fixup, text.encode("ascii", "ignore").encode('utf-8'))

def getCookiesString():
    cookieString=""
    import cookielib
    try:
        cookieJar = cookielib.LWPCookieJar()
        cookieJar.load(cookie_file,ignore_discard=True)
        for index, cookie in enumerate(cookieJar):
            cookieString+=cookie.name + "=" + cookie.value +";"
    except: 
        import sys,traceback
        traceback.print_exc(file=sys.stdout)
    return cookieString
    
def addDir(name,url,mode,iconimage,fanart,description):
	u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
	ok=True
	liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
	liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
	liz.setProperty('fanart_image', fanart)
	if mode==100 or mode==101:
		liz.setProperty("IsPlayable","true")
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
	else:
		ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
	return ok
   
def setView(content, viewType):
    ''' Why recode whats allready written and works well,
    Thanks go to Eldrado for it '''
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':

        print addon.get_setting(viewType)
        if addon.get_setting(viewType) == 'Info':
            VT = '504'
        elif addon.get_setting(viewType) == 'Info2':
            VT = '503'
        elif addon.get_setting(viewType) == 'Info3':
            VT = '515'
        elif addon.get_setting(viewType) == 'Fanart':
            VT = '508'
        elif addon.get_setting(viewType) == 'Poster Wrap':
            VT = '501'
        elif addon.get_setting(viewType) == 'Big List':
            VT = '51'
        elif addon.get_setting(viewType) == 'Low List':
            VT = '724'
        elif addon.get_setting(viewType) == 'List':
            VT = '50'
        elif addon.get_setting(viewType) == 'Default Menu View':
            VT = addon.get_setting('default-view1')
        elif addon.get_setting(viewType) == 'Default TV Shows View':
            VT = addon.get_setting('default-view2')
        elif addon.get_setting(viewType) == 'Default Episodes View':
            VT = addon.get_setting('default-view3')
        elif addon.get_setting(viewType) == 'Default Movies View':
            VT = addon.get_setting('default-view4')
        elif addon.get_setting(viewType) == 'Default Docs View':
            VT = addon.get_setting('default-view5')
        elif addon.get_setting(viewType) == 'Default Cartoons View':
            VT = addon.get_setting('default-view6')
        elif addon.get_setting(viewType) == 'Default Anime View':
            VT = addon.get_setting('default-view7')

        print viewType
        print VT
        
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ( int(VT) ) )

    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )
    xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_MPAA_RATING )



params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
	url=urllib.unquote_plus(params["url"])
except:
	pass
try:
	name=urllib.unquote_plus(params["name"])
except:
	pass
try:
	iconimage=urllib.unquote_plus(params["iconimage"])
except:
	pass
try:
	mode=int(params["mode"])
except:
	pass
try:
	description=urllib.unquote_plus(params["description"])
except:
	pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 3 : Genres(url)
elif mode == 4 : Alpha(url)
elif mode == 5 : Get_content(url)
elif mode == 8 : Search()
elif mode ==10 : Get_epis(url)
elif mode ==100: RESOLVE(url,name)
elif mode ==101: alt_RESOLVE(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
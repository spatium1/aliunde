# -*- coding: utf-8 -*-
#------------------------------------------------------------
# http://www.youtube.com/user/mrrevjohn
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.mrrevjohn'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "PLMGAeluSyTpJXmgmGyOkd4KjAd7HPPAkx"
YOUTUBE_CHANNEL_ID_2 = "PLMGAeluSyTpLvYZ_WWC-2peIa4xZDgZtH"
YOUTUBE_CHANNEL_ID_3 = "PLMGAeluSyTpKIBQKZcVAIk68IeWyccM3-"
YOUTUBE_CHANNEL_ID_4 = "PLMGAeluSyTpJT8Q9uhCkpoS39iX2dsiEG"
YOUTUBE_CHANNEL_ID_5 = "PLMGAeluSyTpLwolFZ8Ml_1JyWKyX57SDo"
YOUTUBE_CHANNEL_ID_6 = "PLMGAeluSyTpLnTl_JkExfsf7-NKZbXBeN"
YOUTUBE_CHANNEL_ID_7 = "PLMGAeluSyTpIco2cZMZM9FMgEeovWfOBz"
YOUTUBE_CHANNEL_ID_8 = "PLMGAeluSyTpJThM4-OQ8h65tTK1HSnrL-"
YOUTUBE_CHANNEL_ID_9 = "PLMGAeluSyTpIPlF5KzHycLcHvF0C_aquY"
YOUTUBE_CHANNEL_ID_10 = "PLMGAeluSyTpKQfnfuyBLzfXdSv7kKCZGz"
YOUTUBE_CHANNEL_ID_11 = "PLMGAeluSyTpLPmv_KRZ41fmNGJDcMl5--"
YOUTUBE_CHANNEL_ID_12 = "PLMGAeluSyTpLUU-lMK8LpqWX1Of-caYv_"
YOUTUBE_CHANNEL_ID_13 = "PLMGAeluSyTpLBOgsYTMVld3opG1bYKm9J"
YOUTUBE_CHANNEL_ID_14 = "PLMGAeluSyTpLW1PX8OyUkqPWVwWXMEqhx"
YOUTUBE_CHANNEL_ID_15 = "PLMGAeluSyTpI3hLCxGqyXK1pUfoaaQx1W"
YOUTUBE_CHANNEL_ID_16 = "PLMGAeluSyTpLEqn3yqoQPgZs31f8azy1L"
YOUTUBE_CHANNEL_ID_17 = "PLMGAeluSyTpIXKepl-UTVNa4QSus44Lca"
YOUTUBE_CHANNEL_ID_18 = "PLMGAeluSyTpLsbnJBWbHJtdqxU2iuZvMs"
YOUTUBE_CHANNEL_ID_19 = "PLMGAeluSyTpKyiGsEXZ9VzV9LwOn7Tnvc"
YOUTUBE_CHANNEL_ID_20 = "PLMGAeluSyTpKdzRoHGU8fe_L3Ohy97ix9"
YOUTUBE_CHANNEL_ID_21 = "PLMGAeluSyTpLZ228_fWg67tKcDSq--Zmd"
YOUTUBE_CHANNEL_ID_22 = "PLMGAeluSyTpIaZqvEY4xW5mmAu0PAqRVK"
YOUTUBE_CHANNEL_ID_23 = "PLMGAeluSyTpITBwJqx7cXn_ndRqdrO2Sp"
YOUTUBE_CHANNEL_ID_24 = "PLMGAeluSyTpIv9uUSu3DBIUrm2Tm_OY0I"
YOUTUBE_CHANNEL_ID_25 = "PLMGAeluSyTpJdZln0kYw5ESmv5ky0gB_c"
YOUTUBE_CHANNEL_ID_26 = "PLMGAeluSyTpJwfFGReRVQ35SFGkQuajDy"
YOUTUBE_CHANNEL_ID_27 = "PLMGAeluSyTpKcGRAdllyOdOAuK0VGKCvc"
YOUTUBE_CHANNEL_ID_28 = "PLMGAeluSyTpJ_CORXDZUEKBnAOgxKOL-n"
YOUTUBE_CHANNEL_ID_29 = "PLtc57NTUizP6mUx4936fvX11B-1T_dysO"
YOUTUBE_CHANNEL_ID_30 = "PLtc57NTUizP538OlT9gAhMhOTv1v5BB4m"
YOUTUBE_CHANNEL_ID_31 = "PLMGAeluSyTpJZi-xYdpthyG-50hDAC6U2"
YOUTUBE_CHANNEL_ID_32 = "PLMGAeluSyTpLz-8AWVeZHzIS6zzWxMJ9Z"

# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2017",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2017.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2016",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2016.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2015",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2015.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2014",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2014.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2013",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2013.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2012",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2012.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2011",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2011.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2010",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2010.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2009",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2009.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2008",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2008.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Bangers 2007",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/2007.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Outlaw Stockcars",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/outlaws.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="WSCC Ministox and Senior Minis",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/minis.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WSCC Super Bangers",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/supers.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WSCC Old Tapes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_32+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/tapes.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Crazy 5 Enduros",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/crazy5.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="National Banger Events",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/big.jpg",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Brisca F1 Stockcars",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/f1.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Brisca F2 Stockcars",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/f2.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Jet Sprint",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/jet.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="RJ's Racing Movies",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/movies.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="BBC Gears and Tears",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/Gears.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Banger Boys TV series",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/boys.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Roosecote Raceway",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/roosecote.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Nascar Full Replays 2016",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/nascar2016.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Nascar Full Replays 2015",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/nascar2015.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Stoke Raceway",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/stoke.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Brampton Raceway",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/brampton.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Skegness Stadium",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/skegness.jpg",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Hednesford Hills Raceway",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/hednesford.jpg",
		folder=True )
 
    plugintools.add_item( 
        #action="", 
        title="Birminham Wheels Raceway",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/wheels.jpg",
		folder=True )
 
    plugintools.add_item( 
        #action="", 
        title="Coventry Stadium",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="http://johnmarlow.net/kodi/thumbs/coventry.jpg",
		folder=True )
		
run()


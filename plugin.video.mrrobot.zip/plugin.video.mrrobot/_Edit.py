import xbmcaddon

MainBase = 'https://goo.gl/dShzGr'
addon = xbmcaddon.Addon('plugin.video.mrrobot')
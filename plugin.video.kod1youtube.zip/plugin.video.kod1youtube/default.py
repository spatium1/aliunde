# -*- coding: utf-8 -*-
#------------------------------------------------------------
# Thanks to the Authors of the base code
#------------------------------------------------------------
# License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Based on code from youtube addon
#
# modified by: SkymashiTV
#------------------------------------------------------------

import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.kod1youtube'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')

YOUTUBE_CHANNEL_ID_1 = "UCugb4RRSarB8uswQNGx6SPQ" 	            #kod1 video tutorials
YOUTUBE_CHANNEL_ID_2 = "PLI8wLmUa7v4iu-V_p1o2RqHbg6pK7I2G6" 	#PLAY ALL VIDEOS
YOUTUBE_CHANNEL_ID_3 = "PLI8wLmUa7v4hv0bCoya3KopvG7aWgpjXv" 	#KOD1 REPO INSTALL
YOUTUBE_CHANNEL_ID_4 = "PLI8wLmUa7v4iLsbW3gbAfGMKe3WsvY6ii"     #INSTALL ADDONS USING KOD1 REPO
YOUTUBE_CHANNEL_ID_5 = "PLI8wLmUa7v4gkOLQvN4aQPrUHiKXCs7un"     #Kod1 APP INSTALLER
YOUTUBE_CHANNEL_ID_6 = "PLI8wLmUa7v4gQz0-iptCOYy6NaVc0lt58"     #COMMUNITY PORTAL BACKUP-RESTORE KODI
YOUTUBE_CHANNEL_ID_7 = "PLI8wLmUa7v4gVYKs811zeL56fuQM2ET7N"     #More BACK UP AND RESTORE VIDEOS
YOUTUBE_CHANNEL_ID_8 = "PLI8wLmUa7v4i8vdDoKgNpCUKUrvAg3LFN"     #Fixes
YOUTUBE_CHANNEL_ID_9 = "PLI8wLmUa7v4iwqEfetfKjHqq7qiQrS5w_"     #TRAKT TV VIDEOS
YOUTUBE_CHANNEL_ID_10 = "PLI8wLmUa7v4hn__HppFXOQ9PPcUdITl9W"    #Downloader for Fire Devices
YOUTUBE_CHANNEL_ID_11 = "PLI8wLmUa7v4iCgeXb7RIswUNhg8iP-NyR"     #FIRESTICK-FIRE TV BOX VIDEOS
YOUTUBE_CHANNEL_ID_12 = "PLI8wLmUa7v4hqoV90mav7bvOSd10ZVBjp"     #ADDONS
YOUTUBE_CHANNEL_ID_13 = "PLI8wLmUa7v4jQtIq0NEovrxy4-mX0ysW2"     #LAUNCHERS
YOUTUBE_CHANNEL_ID_14 = "PLI8wLmUa7v4ixPrMMcckDBS7K9zRND4_E"     #ES FILE EXPLORER
YOUTUBE_CHANNEL_ID_15 = "PLI8wLmUa7v4gBJAiLIOi7Cyp3i2_Wlk2z"     #WINDOWS
YOUTUBE_CHANNEL_ID_16 = "PLI8wLmUa7v4haI3pyzIvQjszsTqRv7ZVG"     #UPDATES
YOUTUBE_CHANNEL_ID_17 = "PLI8wLmUa7v4jdKmsuaR__gdqS1h0Wfpex"     #TEAMVIEWER
YOUTUBE_CHANNEL_ID_18 = "PLI8wLmUa7v4iwSCRVjdkY7eX6nh93TdFl"     #SCREEN ISSUES
YOUTUBE_CHANNEL_ID_19 = "PLI8wLmUa7v4g8CeOXk1evlMyaOwhAqf1_"     #BASIC KODI SETTINGS
YOUTUBE_CHANNEL_ID_20 = "PLI8wLmUa7v4imtp9bQc-SAB7jFwtCO8R2"     #UNINSTALL VIDEOS
YOUTUBE_CHANNEL_ID_21 = "PLI8wLmUa7v4gianHSnPxiZtOdVa7JLy90"     #Shortcuts
YOUTUBE_CHANNEL_ID_22 = "PLI8wLmUa7v4juNy50bqoQuoV5V19YV4Kh"     #BLUETOOTH
YOUTUBE_CHANNEL_ID_23 = "PLI8wLmUa7v4iwqEfetfKjHqq7qiQrS5w_"     #TRAKT TV VIDEOS
YOUTUBE_CHANNEL_ID_24 = "PLI8wLmUa7v4i7A6zW9zn2aDzeAY0TdKM-"     #VOLUME-SOUND ISSUES
YOUTUBE_CHANNEL_ID_25 = "PLI8wLmUa7v4hkFCqinTYny3ou2w4K4Ekj"     #YouTube
YOUTUBE_CHANNEL_ID_26 = "PLI8wLmUa7v4iYSJzhCJeQWVNu-5itZwRI"     #SUBTITLES FOR KODI
YOUTUBE_CHANNEL_ID_27 = "PLI8wLmUa7v4htgM6rQ2MMqWzi6ICtgTZS"     #HOW TO FIX ALMOST ANY ANDROID BOX STUCK ON BOOT LOGO
YOUTUBE_CHANNEL_ID_28 = "PLI8wLmUa7v4jOG_-_dGlswos_U0xiGzZb"     #KODI FOLDER
YOUTUBE_CHANNEL_ID_29 = "PLI8wLmUa7v4i2tkLuHKyha5JdCbPgFtWK"     #Wipe Kodi-Fresh Start
YOUTUBE_CHANNEL_ID_30 = "PLI8wLmUa7v4gOs8OKZ6gkrCPAEyces9O_"     #Factory Reset
YOUTUBE_CHANNEL_ID_31 = "PLI8wLmUa7v4guGGIWVYyxPgP65DtsYb5Z"     #Settings


# Entry point
def run():
    plugintools.log("docu.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("docu.main_list "+repr(params))

    plugintools.add_item( 
        #action="", 
        title="kod1 video tutorials",
        url="plugin://plugin.video.youtube/channel/"+YOUTUBE_CHANNEL_ID_1+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="PLAY ALL VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_2+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="KOD1 REPO INSTALL",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_3+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="INSTALL ADDONS USING KOD1 REPO",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_4+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Kod1 APP INSTALLER",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_5+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="COMMUNITY PORTAL BACKUP-RESTORE KODI",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_6+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="More BACK UP AND RESTORE VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_7+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Fixes",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_8+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="TRAKT TV VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_9+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Downloader for Fire Devices",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_10+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="FIRESTICK-FIRE TV BOX VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_11+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="ADDONS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_12+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="LAUNCHERS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_13+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="ES FILE EXPLORER",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_14+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="WINDOWS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_15+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="UPDATES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_16+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="TEAMVIEWER",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_17+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="SCREEN ISSUES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_18+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="BASIC KODI SETTINGS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_19+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="UNINSTALL VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_20+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Shortcuts",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_21+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="BLUETOOTH",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_22+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="TRAKT TV VIDEOS",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_23+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="VOLUME-SOUND ISSUES",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_24+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="YouTube",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_25+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="SUBTITLES FOR KODI",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_26+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="HOW TO FIX ALMOST ANY ANDROID BOX STUCK ON BOOT LOGO",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_27+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="KODI FOLDER",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_28+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )

    plugintools.add_item( 
        #action="", 
        title="Wipe Kodi-Fresh Start",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_29+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Factory Reset",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_30+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
    plugintools.add_item( 
        #action="", 
        title="Settings",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID_31+"/",
        thumbnail="https://www.dropbox.com/s/sma0y0ixkcjfh4j/icon.png?dl=1",
		fanart="https://www.dropbox.com/s/ykikp362g5x9gg2/fanart.jpg?dl=1",
        folder=True )
		
run()

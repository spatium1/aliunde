import xbmcaddon

MainBase = 'http://www.gtandroid.anarchymediarevolution.com/files/homea.txt'
addon = xbmcaddon.Addon('plugin.audio.thunderstruck')